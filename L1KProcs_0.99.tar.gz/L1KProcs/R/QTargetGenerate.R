##########################################################
## L1K Data quantile target generation
##
## The function is to generate target vector for quantile normalization.
## Three ways to provide target
## 1. User specify by providing R data namefile 
## 2. Default target vector in data/QTarget.rda of the package. 
## 3. Generate target using this function TargetGenerate.
##
## Paramters
## outpath: the path where to put all the processed data and their information. 
## lstNames: a vector of well names.
## Qsize:size of sample to generate target.
## RandNo: repeat number.
## check: FALSE only for inner use.
## Output
## QTarget.rda
## Qcorrelation.rda
## They are stored in the folder outpath. 

TargetGenerate <- function(outpath="l1kdata",lstNames=NULL,Qsize=1000,RandNo=10,check=TRUE){
  ## Generate targets
  if(check){
    if(!file.exists(outpath))
      stop(outpath, " does not exists!")
    if(is.null(lstNames)){  
      if(CheckData(outpath)){
        load(file.path(outpath, "data_summary","lstNames.rda"))
      }else{
        stop("lstNames is not specified! Please perform DataStorage to generate well names.")
      }
    }
  }
  TargetDataSet=NULL
  if(Qsize<length(lstNames)){
    for(i in 1:RandNo){
      lstTargetNames <- sample(lstNames,size=Qsize,replace=TRUE)
      TargetDataSet <- cbind(TargetDataSet,QTargetGenerate(lstTargetNames,outpath=outpath))
    }
    ##  save(TargetDataSet,file = paste(outpath,"AllTarget.rda",sep="/"))
    QTarget <- apply(TargetDataSet,1,mean)
    save(QTarget,file = file.path(outpath,"data_summary","QTarget.rda"))
    var1 <- apply(TargetDataSet,1,var);
    var2 <- apply(TargetDataSet,2,var);
    Fvalue <- (sum(var1)/length(var1))/(sum(var2)/length(var2));
    Qcor <- cor(TargetDataSet)
    save(Fvalue, file = file.path(outpath,"data_summary","Fvalue.rda"))
    save(Qcor, file = file.path(outpath,"data_summary","Qcorrelation.rda"))
  }else{
    lstTargetNames <- lstNames
    suppressWarnings(TargetDataSet <- QTargetGenerate(lstTargetNames,outpath=outpath))
    QTarget <- TargetDataSet
    save(QTarget,file = file.path(outpath,"data_summary","QTarget.rda"))
  }
}
  


