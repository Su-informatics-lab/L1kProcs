initial.class <- function(outpath="l1kdata",lstPlates=NULL,target,platethresh=0.5,wellthresh=0.6,check=TRUE){
  if(check){
    if( is.null(lstPlates)){
      if(!CheckData(outpath))
        stop("lstPlates is not specified. Please provide plate list.")
      load(file.path(outpath, "data_summary","lstPlates.rda"))
    }
  }
  targetInfo <- ifelse(is.logical(target),ifelse(target,"dataset","default"),target)
  dups <- lapply(lstPlates,function(x){
    tmp <- unlist(strsplit(x,"_"))
    return(lstPlates[grep(paste(paste(tmp[1:3],collapse="_"),".*",paste(tmp[5:length(tmp)],collapse="_"),sep="_"),lstPlates)])
  })
  names(dups) <- lstPlates
  lstPlateInfo <- lapply(lstPlates,function(plate){
    newplate <- PlateInfo(name=plate,storepath=outpath,
                          target=targetInfo,
                          duplicates=dups[[plate]])
    return(newplate)
  })
  names(lstPlateInfo) <- lstPlates
  return(lstPlateInfo)
}

              
