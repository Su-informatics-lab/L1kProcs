##########################################################
## L1K Data Processing Pipeline 
##
## It is to processing data generate by L1000 platform.
## It addresses three challedges for L1000 data processing.
## 1. Peak calling method: Fuzzy c-means Guassian mixture model
## 2. Experiment bias: Quantile Normalization
## 3. Quality control: plate based and well based
##
## Functions of L1kDataProcs.
## 1. Peaking calling, raw data (.lxb) -> raw expression data (.csv and .gct), per well
## 2. Quatile Normalization. raw, normalized, LFC expression data (.gct), per plate
## 3. Coverting expression of landmark genes to 22000 genes. per plate
## 4. Quality Control. Indicate bad quality plates and wells.

########################
## Checking parameters
#######################
l1kpreprocs <- function(datapath=NULL,outpath="l1kdata",target=FALSE, plot=TRUE, ifAll=TRUE,
                        Qsize=1000,RandNo=10, nthread=1,verbose=FALSE, pth=0.5, wth=0.6,
                        ifqctr=TRUE,control.specify=NULL,overwrite=FALSE){
  message("[",format(Sys.time(), "%m-%d-%Y %T"),"]","L1000 data processing pipeline")
  message("********************************************************")
  message("[",format(Sys.time(), "%m-%d-%Y %T"),"]","Checking paramters ... ",appendLF=FALSE)
  if(is.null(datapath)) stop("Argument datapath is missing. See help for details.")
  if(!file.exists(datapath)){
    stop(datapath," does not exists!")
  }
  if(!file.exists(outpath)) {
    dir.create(outpath)
  }
  suppressWarnings(dir.create(file.path(outpath,"data_summary")))
  if(is.logical(target)){
    if(target==FALSE){
      targetmode <- 0
      QTarget <- get(data("QTarget",package="L1KProcs",envir=.GlobalEnv))
    }else{
      targetmode <- 1
    }
  }else{
    if(file.exists(target)){
      QTarget <- read.delim(target,sep="\n",stringsAsFactors=FALSE,header=FALSE)
      QTarget <- as.vector(QTarget[[1]])
      save(QTarget,file.path(outpath, "data_summary","QTarget.rda"))
      targetmode <- 0
    }else{
      warning(target , "does not exists!. Generate from data instead!.")
      targetmode <- 1
    }
  }
  message("OK.")
  ##Start Computing.
  message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Initialization.")
  tmp <- DataStorage(datapath,outpath)
  lstPlates <- get(load(file.path(outpath, "data_summary","lstPlates.rda")))
  lstNames <- get(load(file.path(outpath, "data_summary","lstNames.rda")))
  lstfiles <- get(load(file.path(outpath, "data_summary","lstfiles.rda")))
  lstPlateInfo <- initial.class(outpath,lstPlates,target=target,check=FALSE)
  
  message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Peak calling.")
  Nerrs <- PeakCalling(outpath=outpath,lstNames=lstNames,lstfiles=lstfiles,
                          nthread=nthread,overwrite=overwrite,check=FALSE)

  tmp <- do.call(rbind,lapply(strsplit(names(Nerrs),"_"),function(x) paste(x[1:6],collapse="_")))
  lstPerrN <- split(Nerrs,tmp)
  lstPlateInfo <- lapply(names(lstPerrN),function(Pname){
    mode(lstPerrN[[Pname]]) <- "numeric"
    lstPlateInfo[[Pname]]@wellNaNo <- lstPerrN[[Pname]]
    return(lstPlateInfo[[Pname]])
  })
  names(lstPlateInfo) <- lstPlates

  if(targetmode==1){
    message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Generating target from data set.")
    TargetGenerate(outpath=outpath,lstNames=lstNames,
                   Qsize=Qsize,RandNo=RandNo,check=FALSE)
    QTarget <- get(file.path(outpath, "data_summary","QTarget.rda"))
  }

  message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Gene expression normalization.")
  expNorm(lstPlates,QTarget,outpath,nthread,overwrite,check=FALSE)

  message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Summarize control wells.")
  PlateMap <- get(data("PlateMap",package="L1KProcs",envir=.GlobalEnv))
  l1kControls <- get(data("l1kControls",package="L1KProcs",envir=.GlobalEnv))
  lstControlInfo <- lapply(lstPlates,function(PlateName){
    lstctr.info <- FindControls(PlateName,PlateMap,l1kControls,
                                control.specify=control.specify)
  })
  names(lstControlInfo) <- lstPlates
  lstPlateInfo <- lapply(names(lstControlInfo),function(Pname){
    lstPlateInfo[[Pname]]@controlWells <- lstControlInfo[[Pname]][["controls"]]
    lstPlateInfo[[Pname]]@majorcontrol <- lstControlInfo[[Pname]][["majorctr"]]
    return(lstPlateInfo[[Pname]])
  })
  names(lstPlateInfo) <- lstPlates              
  lstControls <- lapply(lstPlateInfo,function(x) {
    controls <- x@controlWells
    majorctr<- x@majorcontrol
    return(names(controls)[controls==majorctr])
  })
  names(lstControls) <- names(lstPlateInfo)
  lstdupPlates <- lapply(lstPlateInfo,function(x) {
    dup <- x@duplicates
  })
  names(lstdupPlates) <- names(lstPlateInfo)
  
  if(ifqctr){
    message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Quality control.")
    lstRes <- QualityControl(outpath,lstControls,
                             pth=pth,wth=wth,
                             lstPlates,lstdupPlates,
                             nthread,check=FALSE)
    lstPlateInfo <- lapply(names(lstRes),function(Pname){
      lstPlateInfo[[Pname]]@covcontrol <- lstRes[[Pname]][["covcontrol"]]
      lstPlateInfo[[Pname]]@ifquality<- lstRes[[Pname]][["ifquality"]]
      lstPlateInfo[[Pname]]@covwells<- lstRes[[Pname]][["covwells"]]
      lstPlateInfo[[Pname]]@goodwells  <-
        rownames(lstRes[[Pname]][["covwells"]])[which(lstRes[[Pname]][["covwells"]][,2]==TRUE)]
      return(lstPlateInfo[[Pname]]) 
    })
    names(lstPlateInfo) <- lstPlates       
    lstControls <- lapply(lstPlates,function(x){
      intersect(lstControls[[x]],lstPlateInfo[[x]]@goodwells)})
  }
  if(ifqctr&plot){
    PlatePlot(lstPlateInfo,file.path(outpath,"data_summary","CorPlates.png"),lstPlates)
    WellPlot(lstPlateInfo,file.path(outpath,"data_summary","CorWells.png"),lstPlates)
  }
  message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Generating log fold change data.")
  expLFC(lstPlates,lstControls,
         outpath=outpath,nthread=nthread,
         overwrite=overwrite,check=FALSE)

  if(ifAll){
    message("[",format(Sys.time(), "%m-%d-%Y %T"),"] Converting to all gene expression.")
    ConvertExp(lstPlates=lstPlates,outpath=outpath,nthread=nthread,overwrite=overwrite,check=FALSE)
  }
  return(lstPlateInfo)
}
