##########################################################
## L1K Data Normalization
##
## The function is to generate raw, normalized  gene expression data.
##
## Paramters
## lstPlates: a vector of plate names
## QTarget: a vector as target for quantile normalization.
## outpath: the path where to put all the processed data and their information.
## nthread: parallel number. [Default=1]
## overwrite: if overwrite existing files. [Default=FALSE]
## check: FALSE only for inner use.
## Output
## [platename]_Raw.gct
## [platename].gct
## They are stored in the folder outpath. 

expNorm <- function(lstPlates=NULL,QTarget=NULL,outpath="l1kdata",nthread=1,overwrite=FALSE,check=TRUE){
  if(check){
    if(is.null(lstPlates)){
      if(!CheckData(outpath)){
        DataStorage.2(outpath)}
      load(file.path(outpath, "data_summary","lstPlates.rda"))
    }
    if(is.null(QTarget)){
      data("QTarget",package="L1KDataProcs",envir=.GlobalEnv)
    }
    if(nthread<1){
      warning("Number must be positive!. Process with no parallel!.")
      nthread <- 1
    }
  }
  
  if(nthread==1){
    Nerrs <- list()
    for(i in 1:length(lstPlates)){
      o <- QNormgctPlate(lstPlates[i],QTarget,outpath,overwrite=overwrite)
    }
  }else{
    if(length(lstPlates)<nthread) nthread <- length(lstPlates)
    cl <- makeCluster(nthread)
    registerDoParallel(cl)
    clusterExport(cl, c("QNormgctPlate","QTarget","ReadQNData","ReadGCT","WriteGCT","ModeShortName","ParseDataName"))
    k <- 1
    while( k <length(lstPlates)){
      iStart <- k
      iEnd <- k+nthread-1
      if(iEnd>length(lstPlates)) iEnd <- length(lstPlates)
      o <- foreach(i=iStart:iEnd) %dopar% {
        res <- QNormgctPlate(lstPlates[i],outpath,QTarget,outpath,overwrite=overwrite)
      }
      k <- k+nthread
    }
    stopCluster(cl)
  }
}

