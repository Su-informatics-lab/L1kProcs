##########################################################
## L1K Data name list generation
##
## The function can extract the list of all well names based on the filenames of raw L1000 data (.lxb) in the data folder.
##
## Paramters
## datapath: the path where to store the raw data.
##           They can be stored in different folders under the folder: datapath.
## outpath: the path where to put all the processed data and their information. 
## filemode: "folder": datapath is a folder
##           "list"  " datapath is a filelist, path of one well data file per line.
## Output
## lstfiles.rda: the paths of well names
## lstNames.rda: the list of well names
## lstPlates.rda: the list of plate names
## They are stored in the folder outpath. 

DataStorage <- function(datapath=NULL,outpath="l1kdata"){
  if(is.null(datapath)) stop("Argument datapath is missing. See help for details.")
  if(!file.exists(datapath)) stop(datapath," does not exists!")
  if(!file.exists(outpath)) {
    dir.create(outpath)
  }
  if(!file.exists(file.path(outpath,"data_summary"))){
    dir.create(file.path(outpath,"data_summary"))
  }
  outpath <- file.path(outpath,"data_summary")
  if(length(list.files(datapath))==0){
    filemode <- "list"
  }else{
    filemode <- "folder"
  }
  if(filemode=="folder"){
    lstAllFilePaths <- list.files(path=datapath,pattern="*.lxb",recursive=TRUE)
    lstAllFileNames <- unlist(strsplit(lstAllFilePaths,split="/"))
    lstDataNames <- lstAllFileNames[grep(pattern="*.lxb",lstAllFileNames)]
    lstNames <- sub(".lxb","",lstDataNames)
    lstfiles <- paste(datapath,lstAllFilePaths,sep="/")
    save(lstNames,file = paste(outpath,"/lstNames.rda",sep=""))
    save(lstfiles,file = paste(outpath,"/lstfiles.rda",sep=""))
    lstPlates <- unique(unlist(lapply(lstNames,function(x){
      tmp <- unlist(strsplit(x,"_"))
      return(paste(tmp[1:(length(tmp)-1)],collapse="_"))
    })))
    ##  lstPlates <- unique(lstAllFileNames[grep(pattern="HI..LO$",lstAllFileNames)])
    save(lstPlates,file = paste(outpath,"/lstPlates.rda",sep=""))
    return(c(length(lstPlates),length(lstNames)))
  }else if(filemode=="list"){
    lstAllFileNames <- read.delim(datapath,header=FALSE,stringsAsFactors=FALSE)
    lstDataNames <- lstAllFileNames[grep(pattern="*.lxb",lstAllFileNames)]
    lstfiles <- lstDataNames
    save(lstfiles,file = paste(outpath,"/lstfiles.rda",sep=""))
    lstNames <- unlist(lapply(lstDataNames,function(x) basename))
    lstNames <- sub(".lxb","",lstNames)
    save(lstNames,file = paste(outpath,"/lstNames.rda",sep=""))
    lstPlates <- unique(unlist(lapply(lstNames,function(x){
      tmp <- unlist(strsplit(x,"_"))
      paste(tmp[1:(length(tmp)-1)],collapse="_")
    })))
    ##    lstPlates <- unique(lstAllFileNames[grep(pattern="HI..LO$",lstAllFileNames)])
    save(lstPlates,file = paste(outpath,"/lstPlates.rda",sep=""))
    return(c(plen = length(lstPlates),wlen = length(lstNames)))
  }
}
