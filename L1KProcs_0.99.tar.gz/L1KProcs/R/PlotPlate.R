PlatePlot <- function(lstPlateInfo,outfile,lstPlates=NULL){
  lstPlateInfo <- lstPlateInfo[unlist(lapply(lstPlateInfo,function(x) is(x,"PlateInfo")))]
  if(is.null(lstPlates)){
    lstPlates <- names(lstPlateInfo)
  }else{
    lstPlates <- intersect(lstPlates,names(lstPlateInfo))
  }
  pcor <- lapply(lstPlateInfo,function(x) x@covcontrol)
  names(pcor) <- names(lstPlateInfo)
  if(length(grep("[.]png",outfile))==0) outfile <- paste(outfile,".png",sep="")
  png(outfile)
  ##  png(file.path(outpath,"CorPlates.png"))
  par(oma=c(0,8,0,0),cex.axis=0.4)
  boxplot(pcor,horizontal=TRUE,notch=FALSE, las=1,ylim=c(0,1))
  abline(h=(0:length(pcor))+0.5,lwd=0.5,col="black")
  abline(v=0.9,lwd=2,col="darkgreen",lty=1)
  abline(v=0.7,lwd=2,col="darkorange",lty=1)
  abline(v=0.5,lwd=2,col="darkred",lty=1)
  title("Correlations of Control Wells of Plates")
  garbage <-dev.off()
}

WellPlot <- function(lstPlateInfo,outfile,lstPlates=NULL){
  lstPlateInfo <- lstPlateInfo[unlist(lapply(lstPlateInfo,function(x) is(x,"PlateInfo")))]
  if(is.null(lstPlates)){
    lstPlates <- names(lstPlateInfo)
  }else{
    lstPlates <- intersect(lstPlates,names(lstPlateInfo))
  }
  wcor <- unlist(lapply(lstPlateInfo,function(x) x@covwells[,"covwells"]))
 ## png(file.path(outpath,"CorWells.png"))
  if(length(grep("[.]png",outfile))==0) outfile <- paste(outfile,".png",sep="")
  png(outfile)

  km <- kmeans(wcor,centers=2)
  HistAnalyte <- hist(wcor,breaks=100,plot=FALSE)
  CDFAnalyte <- cumsum(HistAnalyte$counts/sum(HistAnalyte$counts))
  fit <- optim(c(ifelse(km$size[1]<=km$size[2], km$centers[1], km$centers[2]),
                 sd(wcor)/2,
                 ifelse(km$size[1]<=km$size[2], km$centers[2], km$centers[1]),
                 sd(wcor)/2),
               FGMM,NULL,
               HistAnalyte$mids,CDFAnalyte,
               control=list(maxit=10000))
  
  inX <- wcor
  inP <- fit$par
  hist(wcor,breaks=100,main="",xlab="")
  lines(seq(0,1,0.0001),dnorm(seq(0,1,0.0001),mean=inP[1],sd=inP[2]),type="s",
        lwd=2,col="red",ylim=c(0,10))
  points(seq(0,1,0.0001),dnorm(seq(0,1,0.0001),mean=inP[3],sd=inP[4]),type="s",lwd=2,col="green")
  abline(v=0.6,lwd=2,col="darkred",lty=1)               
  title("Distribution of correlation between duplicates")
  garbage <-dev.off()
}
