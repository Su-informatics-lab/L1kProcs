##########################################################
## L1K Data peak calling 
##
## The function can detect peak using GMM method to each analyte for a list of wells.
##
## Paramters
## outpath: the path where to put all the processed data and their information. 
## lstName: a vector of well names.
## lstfiles: a vector of  the paths of wells.
## datapath: the folder for raw data or the filename of the path of each wells.
## nthread: parallel number. [Default=1]
## overwrite: if overwrite existing files. [Default=FALSE]
## Output
## [wellname].csv
## [wellname].gct
## They are stored in the folder outpath. 
dPeak <- function(outpath="l1kdata",filename=NULL,
                  wellname=NULL,overwrite=FALSE,check=TRUE,plot=FALSE,analyteID=c(11:500)){
  if(check){
    if(is.null(filename)| length(grep(".lxb",filename))==0){
      stop("Please specify parameter filename=/path/to/[wellname].lxb")
    }else{
      if(is.null(wellname)){
        wellname <- sub(".lxb","",basename(filename))
      }
    }
    if(!file.exists(outpath))     dir.create(outpath)
    if(!file.exists(filename)) stop(filename," does not exists!")
  }
  Nerr <- suppressWarnings(LXB2Stats(wellname,filename,outpath,overwrite))
  suppressWarnings(Stats2gct(wellname,outpath,overwrite))
  if(plot) {
    AnalytePlot(wellname,filename,outpath,analyteID)
  }
  return(Nerr)
}


PeakCalling <-function(outpath="l1kdata",
                       lstNames=NULL,lstfiles=NULL,
                       datapath=NULL,nthread=1,overwrite=FALSE,check=TRUE){
  if(check){
    ## Check parameters.
    if(!file.exists(outpath)){
      dir.create(outpath)
      dir.create(file.path(outpath, "data_summary"))
    }      
    if(is.null(lstNames) | is.null(lstfiles)){
      if(is.null(datapath)){
        if(CheckData(outpath)){
          load(file.path(outpath, "data_summary","lstNames.rda"))
          load(file.path(outpath, "data_summary","lstfiles.rda"))
        }else{
          stop("Please specify datapath here or use DataStorage function. See DataStorage help for details.")
        }
      }else{
        DataStorage(datapath,outpath)
        load(file.path(outpath, "data_summary","lstNames.rda"))
        load(file.path(outpath, "data_summary","lstfiles.rda"))
      }
    }
    if(nthread<1){
      warning("Number must be positive!. Process with no parallel!.")
      nthread <- 1
    }
  }
  
  Nerrs <- vector()
  if(nthread==1){
    iStart <- 1
    iEnd <- length(lstNames)
    for( i in iStart:iEnd){
      Nerrs[i] <- dPeak(outpath,lstfiles[i],lstNames[i],overwrite=overwrite,check=FALSE)
    }
  }else{
    cl <- makeCluster(nthread)
    registerDoParallel(cl)
    clusterExport(cl, c("dPeak"))
    k <- 1
    c <- 0
    lstNerrs <- list()
    while( k <length(lstNames)){
      iStart <- k
      iEnd <- k+nthread-1
      c <- c + 1
      if(iEnd>length(lstNames)) iEnd <- length(lstNames)
      lstNerrs[[c]] <- foreach(i=iStart:iEnd) %dopar% {
        return(dPeak(outpath,lstfiles[i],lstNames[i],overwrite=overwrite,check=FALSE))
      }
      k <- k+nthread
    }
    Nerrs <- unlist(lstNerrs,recursive=FALSE)
    stopCluster(cl)
  }
  ## if(plot) {
  ##   if(!file.exists(file.path(outpath,"data_summary"))) dir.create(file.path(outpath,"data_summary"))
  ##   pdf(file=file.path(outpath,"data_summary","Well Quality Distribution.pdf"))
  ##   return(hist(unlist(Nerrrs)))
  ##   dev.off()
  ## }else{
  names(Nerrs) <- lstNames
  return(Nerrs)
  ##  }
}
