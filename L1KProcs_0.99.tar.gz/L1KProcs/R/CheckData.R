#############################################
## Check if the required data exists.
CheckData <- function(outpath){
  if(file.exists(file.path(outpath,"data_summary","lstNames.rda")) & file.exists(file.path(outpath,"data_summary","lstPlates.rda")) & file.exists(file.path(outpath,"data_summary","lstfiles.rda"))){
    return(TRUE)
  }else{
    return(FALSE)
  }
}
 
