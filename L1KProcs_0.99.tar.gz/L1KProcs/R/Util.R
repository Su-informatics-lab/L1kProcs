########################################
#              Utilities               #
########################################

## Author: Jing Su
## Date: May 2012
## License: GPL-2

########################################
#            FindControls              #
########################################
FindControls <- function(PlateName,PlateMap,l1kControls,
                         control.excludes=NULL,control.specify=NULL) {
  subMap <- PlateMap[PlateMap$PerturbagenPlate
                     == unlist(strsplit(PlateName,"_"))[1],]
  tmp <- match(subMap$PerturbagenID,l1kControls$PerturbagenName)
  ctrWells <- l1kControls$PerturbagenDesc[na.omit(tmp)]
  names(ctrWells) <- paste(PlateName,subMap$WellName[!is.na(tmp)],sep="_")
  ctrWells <- ctrWells[setdiff(names(ctrWells),control.excludes)]
  majorctr <- ""
  if(!is.null(control.specify)){
    majorctr <- control.specify
  }else{
    Type <- substr(PlateName,1,2)
    if (Type=="KD") {
      majorctr <- "EMPTY_VECTOR"
    }else if(Type=="OE"){
      majorctr <-"UnTrt"
    } else if(Type=="CP"){
      majorctr <-"DMSO"
    } else if(Type=="LJ"){
      majorctr <-"DMSO"
    }
  }
  return (list(controls = ctrWells,majorctr = majorctr))
}

########################################
#               LXB2Stats              #
########################################
GMM <- function(inX, inP) {
  lambda <- 1.25/2
  return(lambda*pnorm(inX,mean=inP[1],sd=inP[2])
         + (1-lambda)*pnorm(inX,mean=inP[3],sd=inP[4]))
}

FGMM <- function(inP,inX,inY) sum((inY-GMM(inX,inP))^2)

LXB2Stats <- function(DataName,filename,outpath,overwrite=FALSE){
  PList <- ParseDataName(DataName)
  DirName <- paste(PList["Plate",],
                   PList["Cell",],
                   PList["Time",],
                   PList["Rep",],
                   PList["BeadSet",],
                   PList["DetectMode",],
                   sep="_")
  ifLXB <- filename
  ofCSV <- paste(outpath,"/",DataName,".csv",sep="")
  message ("From ", ifLXB,"\n\tto ",ofCSV)
  
  if (file.exists(ofCSV)) {
    if (overwrite)
      file.remove(ofCSV)
    else {
      message(ofCSV," exists. Skip.")
      results <- read.csv(ofCSV)
      return(sum(is.na(results[11:nrow(results),"c1"])) + sum(is.na(results[11:nrow(results),"c2"])))
    }
  }
  
  dat<-readFCS(ifLXB)
  data <- dat@exprs
  rawlfc <- cbind(data[,"RID"], log2(data[,"RP1"]))
  colnames(rawlfc) <- c("RID","EXP")

  lfc <- rawlfc[!is.infinite(rawlfc[,"EXP"]),]

  results <- mat.or.vec(500,11)
  colnames(results) <- c("AnalyteN","n1","c1","sd1","n2","c2","sd2","n_peak","n_tot","err","conv")
  results[,"AnalyteN"] <- 1:500

  lambda <- 1.25/2
  for (i in 1:500){
    Analyte <- lfc[i == lfc[,"RID"],"EXP"]
    results[i,"n_tot"] <- length(Analyte)
    if ( i <= 10) {
      results[i,"n_peak"] <- 1
      results[i,"n1"] <- length(Analyte)
      results[i,"c1"] <- median(Analyte)
      results[i,"sd1"] <- sd(Analyte)
      results[i,"n2"] <- NA
      results[i,"c2"] <- NA
      results[i,"sd2"] <- NA
    } else if (1==length(lfc[i == lfc[,"RID"],"EXP"]))
      results[i,"n_peak"] <- 1
    else if (0==length(lfc[i == lfc[,"RID"],"EXP"])) {
      results[i,"n1"] <- NA
      results[i,"c1"] <- NA
      results[i,"n2"] <- NA
      results[i,"c2"] <- NA
      next
    } else if (2==length(lfc[i == lfc[,"RID"],"EXP"])) {
      results[i,"c1"] <- max(lfc[i == lfc[,"RID"],"EXP"])
      results[i,"n1"] <- 1
      results[i,"sd1"] <- 0
      results[i,"c2"] <- min(lfc[i == lfc[,"RID"],"EXP"])
      results[i,"n2"] <- 1
      results[i,"sd2"] <- 0
      next
    } else if (1==length(unique(Analyte))) {
      results[i,"n_peak"] <- 2
      results[i,"n1"] <- round(results[i,"n_tot"]*lambda)
      results[i,"n2"] <- results[i,"n_tot"]-results[i,"n1"]
      results[i,"c1"] <- median(Analyte)
      results[i,"sd1"] <- sd(Analyte)
      results[i,"c2"] <- median(Analyte)
      results[i,"sd2"] <- sd(Analyte)
      results[i,"err"] <- NA
      results[i,"conv"] <- NA
    } else {
      results[i,"n_peak"] <- 2
      HistAnalyte <- hist(Analyte,breaks=500,plot=FALSE)
      CDFAnalyte <- cumsum(HistAnalyte$counts/sum(HistAnalyte$counts))
      km <- kmeans(Analyte,centers=2)
      fit <- optim(c(ifelse(km$size[1]>=km$size[2], km$centers[1], km$centers[2]),sd(Analyte)/2,
                     ifelse(km$size[1]>=km$size[2], km$centers[2], km$centers[1]),sd(Analyte)/2,
                     1.25/2),
                   FGMM,NULL,
                   HistAnalyte$mids,CDFAnalyte,
                   control=list(maxit=10000))
      results[i,"n1"] <- round(results[i,"n_tot"]*lambda)
      results[i,"n2"] <- results[i,"n_tot"]-results[i,"n1"]
      results[i,"c1"] <- fit$par[1]
      results[i,"sd1"] <- fit$par[2]
      results[i,"c2"] <- fit$par[3]
      results[i,"sd2"] <- fit$par[4]
      results[i,"err"] <- fit$value
      results[i,"conv"] <- fit$conv
      fit <- optim(c(ifelse(km$size[1]<km$size[2], km$centers[1], km$centers[2]),sd(Analyte)/2,
                     ifelse(km$size[1]<km$size[2], km$centers[2], km$centers[1]),sd(Analyte)/2,
                     1.25/2),
                   FGMM,NULL,
                   HistAnalyte$mids,CDFAnalyte,
                   control=list(maxit=10000))
      if (results[i,"err"] > fit$value) {
        results[i,"c1"] <- fit$par[1]
        results[i,"sd1"] <- fit$par[2]
        results[i,"c2"] <- fit$par[3]
        results[i,"sd2"] <- fit$par[4]
        results[i,"err"] <- fit$value
        results[i,"conv"] <- fit$conv
      }
    }
  }
  write.csv(results,file=ofCSV)
  return(sum(is.na(results[11:nrow(results),"c1"])) + sum(is.na(results[11:nrow(results),"c2"])))
  message("\tDone!")
}

AnalytePlot <- function(DataName, filename, outpath, analyteID){
  ifLXB <- filename
  ofCSV <- file.path(outpath,paste(DataName,".csv",sep=""))
  ofGCT <- file.path(outpath,paste(DataName,".gct",sep=""))
  GeneList <- read.delim(ofGCT,sep="\t",skip=2,stringsAsFactors=F)[,1]

  suppressWarnings(dat<-readFCS(ifLXB))
  data <- dat@exprs
  rawlfc <- cbind(data[,"RID"], log2(data[,"RP1"]))
  colnames(rawlfc) <- c("RID","EXP")
  lfc <- rawlfc[!is.infinite(rawlfc[,"EXP"]),]

  result <- read.delim(ofCSV,sep=",",stringsAsFactors=F)
  if(!file.exists(file.path(outpath,"WellPlots")))
    dir.create(file.path(outpath,"WellPlots"))
  APlot(DataName,analyteID,lfc,result,GeneList,
              plotpath=file.path(outpath,"WellPlots"))
}

APlot <- function(DataName,analyteID,lfc,result,GeneList,plotpath){
  lambda <- 1.25/2
  for (i in analyteID){
    Analyte <- lfc[i == lfc[,"RID"],"EXP"]
    if(result[i,"n_peak"]==1 || (sum(is.na(result[i,]))!=0)) {
      cat("Analyte",i, "does not have enough beads support!\n")
      next
    } else {
      png(file.path(plotpath,paste(DataName,"-Analyte",i,".png",sep="")))
      x1 <- 0.9*min(Analyte)
      x2 <- 1.1*max(Analyte)
      suppressWarnings(histdata <- hist(Analyte,freq=FALSE,breaks=20,plot=F))
      maxY <- 1.2*max(histdata$density)
      HistAnalyte <- hist(Analyte,breaks=20,freq=F,
                          xlim=range(x1,x2),ylim=range(0,maxY),
                          col="grey",
                          main="GMM Peak Calling",
                          xlab="Expression",ylab="Density")
      expA <- formatC(result[i,"c1"],format="f",digits=2)
      expB <- formatC(result[i,"c2"],format="f",digits=2) 
      sub.txt <- paste("n=",result[i,"n_tot"],"; exp=[",expA,",",expB,"]; supportNo=[",result[i,"n1"],",",result[i,"n2"],"]; err=",formatC(result[i,"err"],format="f",digits=2),sep="")
      mtext(sub.txt,side=3,line=0)
      inX <- seq(x1,x2,0.05)
      y1 <- lambda*dnorm(inX,mean=result[i,"c1"],sd=result[i,"sd1"])
      y2 <- (1-lambda)*dnorm(inX,mean=result[i,"c2"],sd=result[i,"sd2"])
      points(inX,y1,col="red",type="l",lwd=2)
      points(inX,y2,col="blue",type="l",lwd=2)
      pAx <- result[i,"c1"]
      pBx <- result[i,"c2"]
      pAy <-lambda*dnorm(pAx,mean=result[i,"c1"],sd=result[i,"sd1"]) 
      pBy <-(1-lambda)*dnorm(pBx,mean=result[i,"c2"],sd=result[i,"sd2"]) 
      points(pAx,pAy,type="p",col="red",pch=19)
      points(pBx,pBy,type="p",col="blue",pch=19)
      text(pAx,(pAy+0.05),paste("(A) ",GeneList[((i-10)*2-1)],": ",expA,sep=""),font=1.8,col="red")
      text(pBx,(pBy+0.05),paste("(B) ",GeneList[((i-10)*2)],":",expB,sep=""),font=1.8,col="blue")
      dev.off()
    }
  }
}

########################################
#               Stats2gct              #
########################################
Stats2gct <- function(statsDataName, outpath, overwrite=FALSE){
  ifCSV <- paste(outpath,"/",statsDataName,".csv",sep="")
  ofGCT <- paste(outpath,"/",statsDataName,".gct",sep="")
  
  if (file.exists(ofGCT)) {
    if (overwrite)
      file.remove(ofGCT)
    else {
      message(ofGCT," exists. Skip.")
      return()
    }
  }
  U133A <- get(data("U133A",package="L1KProcs",envir=.GlobalEnv))
  PlateMap <- get(data("PlateMap",package="L1KProcs",envir=.GlobalEnv))
  Bead2Gene <- get(data("Bead2Gene",package="L1KProcs",envir=.GlobalEnv))
  
  DPeaks <- read.csv(ifCSV, header = TRUE, stringsAsFactors = FALSE)
  PList <- as.matrix(strsplit(statsDataName,"_")[[1]])
  tmpPList <- as.matrix(strsplit(statsDataName,"_")[[1]])
  if (8 == length(tmpPList)) {
    PList <- as.matrix(c(tmpPList[1:3],paste(tmpPList[4],tmpPList[5],sep="_"),tmpPList[6:8]))
  } else
  PList <- tmpPList
  rownames(PList) <- c("Plate","Cell","Time","Rep",
                       "BeadSet","DetectMode","Well")
  GeneAnno <- Bead2Gene[grep(PList["BeadSet",], Bead2Gene$BeadSetBatch,fixed=TRUE),]
  gctFile <- file(ofGCT,open = "a")
  cat(paste("#1.2","\n",sep=""),
      file = gctFile,append=TRUE)
  cat(paste("1000","\t","1","\n",sep=""),
      file = gctFile,append=TRUE)
  cat(paste("Gene","\t",
            "Name","\t",
            "Description","\t",
            statsDataName,
            "\n",sep=""),
      file = gctFile,append=TRUE)
  for (i in 1:nrow(DPeaks)) {
    # Handling the HI probes
    if ("DUO52HI53LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP52",]
      tmpProbe <- "DP52"
    } else if ("DUO53HI52LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP53",]
      tmpProbe <- "DP53"
    } else if ("DUO45HI44LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP45",]
      tmpProbe <- "DP45"
    } else if ("DUO44HI45LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP44",]
      tmpProbe <- "DP44"
    }
    tmpU133AID <- (U133A$pr_id[U133A$pr_gene_id ==
                               tmpGeneID[1,"EntrezGeneID"]])[1]


    if (!is.na(tmpU133AID)) {
      if (DPeaks[i,"c1"] <=0 | DPeaks[i,"c1"] > 20 | is.na(DPeaks[i, "c1"])|DPeaks[i,"n_tot"]<20) {
        tmpDPeaks <- "NA"
      } else if (1 == DPeaks[i,"c1"] & 1 == DPeaks[i,"c2"] & 2 == DPeaks[i,"n_tot"]){
        tmpDPeaks <- DPeaks[i,"n1"] # Due to a fixed bug in LXB2Stats()
      } else {
        tmpDPeaks <- DPeaks[i,"c1"]
      }
      
      cat(paste(U133A[tmpU133AID,"pr_gene_symbol"],"\t",
                tmpU133AID,"\t",
                paste("Analyte ",as.character(i),", ", tmpProbe, ", ",
                      U133A[tmpU133AID,"pr_gene_title"],sep=""),"\t",
                tmpDPeaks,
                "\n",sep=""),
          file = gctFile,append=TRUE)
    }
    # Handling the LO probes
    if ("DUO52HI53LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP53",]
      tmpProbe <- "DP53"
    } else if ("DUO53HI52LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP52",]
      tmpProbe <- "DP52"
    } else if ("DUO45HI44LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP44",]
      tmpProbe <- "DP44"
    } else if ("DUO44HI45LO"==PList["DetectMode",]) {
      tmpGeneID <- GeneAnno[GeneAnno$LMNXAnalyteID ==
                            paste("Analyte ",as.character(i),sep="") &
                            GeneAnno$BeadSet == "DP45",]
      tmpProbe <- "DP45"
    }
    tmpU133AID <- (U133A$pr_id[U133A$pr_gene_id ==
                               tmpGeneID[1,"EntrezGeneID"]])[1]
    if (!is.na(tmpU133AID)) {
      if (DPeaks[i,"c2"] <=0 | DPeaks[i,"c2"] > 20 |is.na(DPeaks[i, "c2"])|DPeaks[i,"n_tot"]<20) {
        tmpDPeaks <- "NA"
      } else if (1 == DPeaks[i,"c1"] & 1 == DPeaks[i,"c2"] & 2 == DPeaks[i,"n_tot"]){
        tmpDPeaks <- DPeaks[i,"n2"] # Due to a fixed bug in LXB2Stats()
      } else {
        tmpDPeaks <- DPeaks[i,"c2"]
      }
      cat(paste(U133A[tmpU133AID,"pr_gene_symbol"],"\t",
                tmpU133AID,"\t",
                paste("Analyte ",as.character(i),", ", tmpProbe, ", ",
                      U133A[tmpU133AID,"pr_gene_title"],sep=""),"\t",
                tmpDPeaks,
                "\n",sep=""),
          file = gctFile,append=TRUE)
    }
  }
  close(gctFile)
}

########################################
#             QTargetGenerate          #
########################################
QTargetGenerate <- function(lstTargetNames,outpath){
  ProbeNumSet <- mat.or.vec(nr=980,nc=0)
  for(TargetName in lstTargetNames){
    ifGCT <- paste(outpath,"/",TargetName,".gct",sep="")
    tmpGCT <- read.delim(ifGCT,sep="\t",
                         header = TRUE,skip = 2,
                         stringsAsFactors = FALSE)
    if (nrow(tmpGCT)==978)
      tmpDataSet <- c(tmpGCT[[TargetName]],"NA","NA")
    else 
      tmpDataSet <- tmpGCT[[TargetName]]
    ProbeNumSet <- cbind(ProbeNumSet, tmpDataSet)
  }
  numProbeNumSet <- apply(ProbeNumSet,2,as.numeric)
  colnames(numProbeNumSet) <- lstTargetNames
  tmpNA <- is.na(numProbeNumSet)
  colBad <- colnames(tmpNA)[apply(tmpNA,2,sum)>50]
  colGood <- setdiff(colnames(numProbeNumSet),colBad)
  QTarget <- normalize.quantiles.determine.target(numProbeNumSet[,colGood])
  return(QTarget)
}
########################################
#           QNormgctPlate              #
########################################
QNormgctPlate <- function(PlateName,datapath,QTarget,outpath,overwrite=FALSE){
  lstRawDataNames <- sub(".gct","",list.files(datapath,pattern=paste(PlateName,"_[A-P][0-2][0-9].gct",sep="")))
  ifGCT <- file.path(datapath,paste(lstRawDataNames[1],".gct",sep=""))
  tmpGCT <- read.delim(ifGCT,sep="\t",
                       header = TRUE,skip = 2,
                       stringsAsFactors = FALSE)
  ProbeName <- ParseDataName(ifGCT)["ShortModeID",]
  ProbeSet <- tmpGCT[,which(colnames(tmpGCT) %in% c("Gene","Name","Description"))]

  ofGCT <- file.path(outpath,paste(PlateName,"_",ProbeName,".gct",sep=""))
  ofGCTr <- file.path(outpath, paste(PlateName,"_",ProbeName,"_Raw.gct",sep=""))

  if(overwrite){
    if (file.exists(ofGCT) |  file.exists(ofGCTr)) {
      file.remove(ofGCT)
      file.remove(ofGCTr)
    }
  }else{
    if(file.exists(ofGCT) &file.exists(ofGCTr)){
      message(ofGCTr," exists. Skip.")
      return()
    }else if(file.exists(ofGCT)){
      file.remove(ofGCT)
    }else if(file.exists(ofGCTr)){
      file.remove(ofGCTr)
    }      
  }
  
  i <- 0
  n <- length(lstRawDataNames)
  message ("Processing \t",PlateName)
  for (RawDataName in lstRawDataNames){
    i <- i + 1 
    ifGCT <- file.path(datapath,paste(RawDataName,".gct",sep=""))
    tmpGCT <- read.delim(ifGCT,sep="\t",
                         header = TRUE,skip = 2,
                         stringsAsFactors = FALSE)
    tmpDataSet<- data.frame(
      tmpGCT[match(ProbeSet[,"Gene"],tmpGCT[,"Gene"]),
             RawDataName],
      stringsAsFactors = FALSE)
    colnames(tmpDataSet) <- RawDataName
    ProbeSet <- cbind(ProbeSet,tmpDataSet)
  }
  if(ncol(ProbeSet)>4){
    tmpNA <- is.na(ProbeSet[,4:ncol(ProbeSet)])
    colBad <- colnames(tmpNA)[apply(tmpNA,2,sum)>50]
    colGood <- setdiff(colnames(ProbeSet[4:ncol(ProbeSet)]),colBad)
    MAnormProbe <- normalize.quantiles.use.target(as.matrix(ProbeSet[,colGood]),QTarget,copy=TRUE)
    normDataSet <- cbind(ProbeSet[,1:3],
                         MAnormProbe)
    colnames(normDataSet)[4:ncol(normDataSet)] <- colGood
  }else{
    tmpNA <- is.na(ProbeSet[,4:ncol(ProbeSet)])
    colBad <- NULL
    colGood <- NULL
    if(sum(tmpNA)>50){
      colBad <- colnames(ProbeSet)[4]
    }else{
      colGood <- colnames(ProbeSet)[4]
    }
    MAnormProbe <- normalize.quantiles.use.target(as.matrix(ProbeSet[,colGood]),QTarget,copy=TRUE)
    normDataSet <- cbind(ProbeSet[,1:3],
                         MAnormProbe)
    colnames(normDataSet)[4:ncol(normDataSet)] <- colGood
  }    

  suppressWarnings(WriteGCT(normDataSet,ofGCT))
  suppressWarnings(WriteGCT(ProbeSet,ofGCTr))
}


########################################
#                QN2LFC                #
########################################
QN2LFC <- function(PlateName,outpath,lstControlWells=NULL,overwrite=FALSE){
  ProbeName <- ParseDataName(paste(PlateName,"_A01"))["ShortModeID",]
  LFCFileName <- paste(PlateName,"_",ProbeName,"_LFC",sep="")
  ofGCT <- file.path(outpath, paste(LFCFileName,".gct",sep=""))
  if (file.exists(ofGCT)){
    if(overwrite){
      file.remove(ofGCT)
    }else {
      message(ofGCT," exists. Skip.")
      return(NULL)
    }
  }
  QNData <- ReadQNData(PlateName,outpath)
  if (is.null(QNData)) {
    return (NA)
  }  
 
  QN2LFC <- QNData
  ControlList <- na.omit(match(lstControlWells,colnames(QNData)))
  if(length(ControlList)==0){
    warning("No Control Well available ",PlateName)
    return(0)}
  QNControl <- QNData[ControlList]
  if(length(ControlList)==1){
    QN2LFC[,4:ncol(QN2LFC)] <- as.matrix(QNData[,4:ncol(QNData)])-QNControl
  }else{
    QN2LFC[,4:ncol(QN2LFC)] <- QNData[,4:ncol(QNData)]-
      apply(QNControl,1,mean,na.rm=TRUE)}
  WriteGCT(QN2LFC,ofGCT)
}

########################################
#               ReadQNData             #
########################################
ReadQNData <- function(PlateName,outpath){
  ifQNData <- list.files(outpath, pattern=paste(PlateName,"_[4-5][2-5][4-5][2-5].gct",sep=""))
  if (!1==length(ifQNData)) {
    warning("There are", length(ifQNData), "matched QNorm gct file for", PlateName,".")
    warning("\tWhich are", ifQNData)
    return (NULL)
  }
  return(ReadGCT(ifQNData,outpath))
}

########################################
#               ReadGCT                #
########################################
ReadGCT <- function(DataName,outpath){
  if (length(grep(".gct$",DataName))){ ifGCT <- file.path(outpath,DataName)}else{
    ifGCT <- file.path(outpath,paste(DataName,".gct",sep=""))}
  if (!file.exists(ifGCT)) {
    warning("GCT file ", ifGCT," does not exists.")
    return (NA)
  }
  return (read.delim(ifGCT,
                     sep="\t",
                     header = TRUE,skip = 2,
                     stringsAsFactors = FALSE))
}

########################################
#              WriteGCT                #
########################################
WriteGCT <- function(GCTData,ofGCT){
  if (file.exists(ofGCT))    file.remove(ofGCT)
  gctFile <- file(ofGCT,open = "a")
  cat(paste("#1.2","\n",sep=""),
      file = gctFile,append=TRUE)
  cat(paste(nrow(GCTData),"\t",ncol(GCTData)-3,"\n",sep=""),
      file = gctFile,append=TRUE)
  close(gctFile)
  write.table(GCTData,file=ofGCT,append=TRUE,sep="\t",row.names=FALSE,quote=FALSE)
}

########################################
#             ParseDataName            #
########################################
ParseDataName <-  function(lstDataName){
  ParseDataName <- matrix(NA,nrow = 7,ncol = length(lstDataName))
  rownames(ParseDataName) <- c("Plate","Cell","Time","Rep",
                               "BeadSet","DetectMode","Well")
  colnames(ParseDataName) <- lstDataName
  for (i in 1:length(lstDataName)){
    tmpPList <- as.matrix(strsplit(lstDataName[i],"_")[[1]])
    if (8 == length(tmpPList)) {
      ParseDataName[,i] <- as.matrix(c(tmpPList[1:3],paste(tmpPList[4],tmpPList[5],sep="_"),
                                       tmpPList[6:8]))
    } else
    ParseDataName[,i] <- tmpPList
  }
  ShortModeID <- ParseDataName["DetectMode",]
  ShortModeID <- replace(ShortModeID,grep(44,ShortModeID),4445)
  ShortModeID <- replace(ShortModeID,grep(52,ShortModeID),5253)
  ParseDataName <- rbind(ParseDataName,ShortModeID)
  return (ParseDataName)
}
########################################
#            ModeShortName             #
########################################
ModeShortName <- function(DetectMode){
  ModeSName <- DetectMode
  for(i in 1:length(ModeSName)){
    if(grep(44,ModeSName[i])==1)
      ModeSName[i] <- 4445
    else
      ModeSName[i] <- 5253
  }
  return(ModeSName)
}
