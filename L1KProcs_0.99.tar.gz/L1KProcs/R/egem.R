DEG <- function(Data,th=0.5,meanD=NULL,sdD=NULL){
  if(is.null(meanD))
    meanD <- mean(as.vector(Data),na.rm=TRUE)
  if(is.null(sdD))
    sdD <- sd(as.vector(Data),na.rm=TRUE) 
  zx <- apply(Data,2,function(x) pnorm(x,meanD,sdD))
  pd <- apply(zx,2,function(x)(x<0.025))
  pu<- apply(zx,2,function(x) (1-x)<0.025)
  eu <- apply(Data,2,function(x) x>th)
  ed <- apply(Data,2,function(x) x<(-1)*th)
  lstdeg <- list()
  lstdeg[[1]] <- apply(pu&eu,2,function(x) {
    which(x==TRUE)
  })
  lstdeg[[2]] <- apply(pd&ed,2,function(x) {
    which(x==TRUE)
  })
  names(lstdeg) <- c("up","down")
  return(lstdeg) 
}

calEGEM <- function(up.gene.set, down.gene.set, gene.score, weighted.type=0) {
  ngene <- length(gene.score)
  nset <- size(up.gene.set)
  if(size(down.gene.set)!=nset)
    stop("Up and down DEGs sizes are different.")
  up.gene.set.size <- geneSetSize(up.gene.set)
  down.gene.set.size <- geneSetSize(down.gene.set)
  up.sort.idx <- order(gene.score, decreasing=TRUE)
  down.sort.idx <- order(gene.score,decreasing=FALSE)
  up.gene.score.sorted <- gene.score[up.sort.idx]
  down.gene.score.sorted <- gene.score[down.sort.idx]
  up.cumsum.score <- matrix(0, nrow = ngene, ncol = nset)
  down.cumsum.score <- matrix(0, nrow = ngene, ncol = nset)
  min.gene <- max(up.gene.set@GSSizeMin,down.gene.set@GSSizeMin)
  max.gene <- min(up.gene.set@GSSizeMax,down.gene.set@GSSizeMax)

  for (i in 1:nset) {
    ngene.hit <- (up.gene.set.size[i]+down.gene.set.size[i])
    if((ngene.hit<min.gene) | (ngene.hit>max.gene)){
      up.cumsum.score[,i] <- rep(NA,length=ngene)
      down.cumsum.score[,i] <- rep(NA,length=ngene)
    }else{
      ngene.miss <- 2*ngene - ngene.hit
      up.sort.idx.hit <- match(up.gene.set[i], up.sort.idx)
      down.sort.idx.hit <- match(down.gene.set[i], down.sort.idx)
      up.cumsum.score[,i] <- (-1)* 1.0 / ngene.miss
      down.cumsum.score[,i] <- (-1)* 1.0 / ngene.miss
      if( weighted.type == 0 ) {
        up.cumsum.score[up.sort.idx.hit, i] <- 1.0 / ngene.hit
        down.cumsum.score[down.sort.idx.hit, i] <- 1.0 / ngene.hit
      } else if ( weighted.type == 1 ) {
        up.gene.score.sorted.hit <- up.gene.score.sorted[up.sort.idx.hit]
        up.cumsum.score[up.sort.idx.hit, i] <- up.gene.score.sorted.hit / sum(up.gene.score.sorted.hit)
        down.gene.score.sorted.hit <- down.gene.score.sorted[down.sort.idx.hit]
        down.cumsum.score[down.sort.idx.hit, i] <- down.gene.score.sorted.hit / sum(down.gene.score.sorted.hit)
      } else {
        up.gene.score.sorted.hit <- up.gene.score.sorted[up.sort.idx.hit] ** weighted.type
        up.cumsum.score[up.sort.idx.hit, i] <- up.gene.score.sorted.hit / sum(up.gene.score.sorted.hit)      
        down.gene.score.sorted.hit <- down.gene.score.sorted[down.sort.idx.hit] ** weighted.type
        down.cumsum.score[down.sort.idx.hit, i] <- down.gene.score.sorted.hit / sum(down.gene.score.sorted.hit)
      }
    }
  }
  cumsum.score <- (apply(up.cumsum.score, 2, cumsum)+ apply(down.cumsum.score, 2, cumsum))
  t(cumsum.score) # nset rows * ngene cols
}


perform.EGEM <- function(up.gene.set,down.gene.set,gene.data,nthread=1,weighted.type=0){
  cl <- makeCluster(nthread)
  registerDoParallel(cl)
  clusterExport(cl, c("calEGEM","size","geneSetSize"))
  k <- 1
  EGEM <- NULL
  while( k <= ncol(gene.data)){
    iStart <- k
    iEnd <- k+nthread-1
    if(iEnd>ncol(gene.data)) iEnd <- ncol(gene.data)
    o <- foreach(i=iStart:iEnd,.combine=cbind) %dopar% {
      gene.score <- gene.data[,i]
      tmp <- gene.score
      names(tmp) <- NULL
      EGEM.score.cumsum <- calEGEM(up.gene.set, down.gene.set, gene.score, weighted.type=weighted.type)
      tmp1 <-apply(EGEM.score.cumsum, 1, max)
      tmp2 <-apply(EGEM.score.cumsum, 1, min)
      EGEM.ES <- ifelse(tmp1>(-1)*tmp2,tmp1,tmp2) 
      return(EGEM.ES)
    }
    EGEM <- cbind(EGEM,o)
    k <- k+nthread
  }
  colnames(EGEM) <- colnames(gene.data)
  row.names(EGEM) <- up.gene.set@GSNames
  stopCluster(cl)
  return(EGEM)
}

calperm.egem <- function(lstdegs,genelist,nthread=1,weighted.type=0,GSSizeMin=10,GSSizeMax=300){
  upDEG <- lstdegs[["up"]]
  downDEG <- lstdegs[["down"]]
  upDEG.size <- unlist(lapply(upDEG,length))
  downDEG.size <- unlist(lapply(downDEG,length))
  up.gene.set <- new("SeqGeneSet",name="up",geneList=genelist,GS=upDEG,GSNames=names(upDEG),GSSize=upDEG.size,GSSizeMin=c(GSSizeMin),GSSizeMax=(GSSizeMax))
  down.gene.set <- new("SeqGeneSet",name="down",geneList=genelist,GS=downDEG,GSNames=names(downDEG),GSSize=downDEG.size,GSSizeMin=c(GSSizeMin),GSSizeMax=(GSSizeMax))
  gene.score <- seq(1,length(genelist))
  gene.score.perm <- do.call(cbind,lapply(1:100,function(x) sample(gene.score)))
  perm.EGEM <- perform.EGEM(up.gene.set,down.gene.set, gene.score.perm,nthread=nthread,weighted.type=weighted.type)
  mean.perm <- apply(perm.EGEM,1,mean,na.rm=T)
  sd.perm <- apply(perm.EGEM,1,sd,na.rm=T)
  perm.egem <- list(mean.perm=mean.perm,sd.perm=sd.perm)
  return(perm.egem)
}

egem <- function(cpdata=NULL, kddata=NULL,
                 th=0.5,meanD=NULL,sdD=NULL,
                 lib.name=c("A375_96H","A549_75H",
                   "HA1E_96H", "HCC515_96H" ,
                   "HT29_96H", "MCF7_96H",  
                   "PC3_144H", "PC3_96H"),  
                 LINCS=TRUE,nthread=1,weighted.type=0,
                 GSSizeMin=10,GSSizeMax=300,cpdes=NULL,kddes=NULL) {
  ## Parameter checking and initialization
  lstdegs <- NULL
  lstperm <- NULL
  if(LINCS){
    libDEG <- get(data("libDEG",package="L1KAnno"))
    if( length(lib.name)>1| !(lib.name %in% names(libDEG))){
      stop("Please choose a dataset from ",paste(names(libDEG),collapse=", ")," if LINCS is true.")
    }else{
      lstdegs <- libDEG[[lib.name]][c("up","down")]
      mean.perm <- libDEG[[lib.name]][["mean.perm"]]
      sd.perm <- libDEG[[lib.name]][["sd.perm"]]
      lstkddes <- libDEG[[lib.name]][["PtDesc"]]
    }
  }
  if(nthread<1)
    warning("Cluster number must be positive. Do not parallel instead.")
  ## data("genelist",package="EGEM")
  genelist <- get(data("genelist",package="L1KProcs"))
  
  if(is.null(cpdata)){
    stop("Please provide matrix of the compound gene expression log fold change data")
  }else if(!is.matrix(cpdata) |!is.numeric(cpdata)){
    stop("Parameter cpdata is not numeric or is not a matrix.")
  }else{
    cpdata <- cpdata[match(genelist,rownames(cpdata)),]
    if(is.null(cpdes)){
      CNames <- colnames(cpdata)
    }else{
      CNames <- cpdes
      names(CNames) <- colnames(cpdata)    
    }
  }
  if(is.null(kddata)){
    if(is.null(lstdegs)){
      stop("No available DEG features in database. Please provide instead.")
    }else{
      kddegs <- lstdegs
      mean.perm <- mean.perm
      sd.perm <- sd.perm
      PNames <- lstkddes
    }
  }else{
    if(!is.matrix(kddata) |!is.numeric(kddata))
      stop("Parameter kddata is not numeric or is not a matrix.")
    kddata <- kddata[match(genelist,rownames(kddata)),]
    lstdegs2 <- DEG(kddata,th,meanD,sdD)
    lstperm2 <- calperm.egem(lstdegs2,genelist,nthread,weighted.type,GSSizeMin,GSSizeMax)
    if(is.null(kddes)){
      lstkddes2 <- colnames(kddata)
    }else{
      lstkddes2 <- kddes
      names(lstkddes2) <- colnames(kddata)
    }
    if(is.null(lstdegs)){
      kddegs <- lstdegs2
      mean.perm <-lstperm2[["mean.perm"]]
      sd.perm <- lstperm2[["sd.perm"]]
      PNames <- lstkddes2
    }else{
      kddegs <- list()
      kddegs[["up"]] <- unlist(list(lstdegs[["up"]],
                                    lstdegs2[["up"]]),recursive=FALSE)
      kddegs[["down"]] <- unlist(list(lstdegs[["down"]],lstdegs2[["down"]]),recursive=FALSE)
      mean.perm <- c(mean.perm,lstperm2[["mean.perm"]])
      sd.perm <- c(sd.perm,lstperm2[["sd.perm"]] )
      PNames <- c(lstkddes,lstkddes2)
    }
  }
  
  ## egem calculation.
  upDEG <- kddegs[["up"]]
  downDEG <- kddegs[["down"]]
  upDEG.size <- unlist(lapply(upDEG,length))
  downDEG.size <- unlist(lapply(downDEG,length))
  up.gene.set <- new("SeqGeneSet",name="up",geneList=genelist,GS=upDEG,GSNames=names(upDEG),GSSize=upDEG.size,GSSizeMin=c(GSSizeMin),GSSizeMax=(GSSizeMax))
  down.gene.set <- new("SeqGeneSet",name="down",geneList=genelist,GS=downDEG,GSNames=names(downDEG),GSSize=downDEG.size,GSSizeMin=c(GSSizeMin),GSSizeMax=(GSSizeMax))

  dataEGEM <- perform.EGEM(up.gene.set,down.gene.set,cpdata,nthread,weighted.type)
  p.value <- do.call(rbind,lapply(seq(1,nrow(dataEGEM)),function(i){
    pnorm(dataEGEM[i,],mean.perm[i],sd.perm[i])}))
  EGEM <- do.call(rbind,lapply(seq(1,nrow(dataEGEM)),function(i){
    tf <- ((p.value[i,]<0.025)|(p.value[i,]>0.975))
    tmp <- dataEGEM[i,]
    tmp[!tf] <- 0 
    return(tmp)
  }))
  rownames(EGEM) <- rownames(dataEGEM)
  rownames(p.value) <- rownames(dataEGEM)
  EGEMinfo <- list(egem=EGEM,origin.EGEM=dataEGEM,p.value=p.value,mean.perm=mean.perm,sd.perm=sd.perm,DEGs=kddegs,CNames=CNames,PNames=PNames)
}

egem.plot <- function(EGEM,outpath="l1kanalysis"){
  if(!file.exists(outpath)) dir.create(outpath)
  outpng <- file.path(outpath,"EGEM.png")
  if(is.null(EGEM)) return
  if(!is.matrix(EGEM) | min(dim(EGEM)==1))
    EGEM <- cbind(EGEM,rep(0,max(dim(EGEM))))
  EGEM <- t(EGEM)
  EGEM[is.na(EGEM)] <- 0
  e1 <- apply(EGEM,1,function(x) sum(x!=0))>0
  e2 <- apply(EGEM,2,function(x) sum(x!=0))>0
  EGEM <- EGEM[e1,e2]
  png(outpng)
  heatmap.2(EGEM,trace="none",col="greenred",symkey=TRUE)
  garbage <-dev.off()
  outpng <- file.path(outpath,"histEGEM.png")
  png(outpng)          
  hist(as.vector(EGEM)[as.vector(EGEM)!=0],xlab="EGEM scores (!=0)",main="Distribution of EGEM scores (!=0)")
  garbage <- dev.off()  
}

egem.analyze <- function(EGEM,th=0.05,outpath="l1kanalysis",print=TRUE){
  if(!file.exists(outpath)) dir.create(outpath)
  lstSigs <- apply(EGEM,2,function(x){
    x <- x[!is.na(x)]
    return(list("same"=rownames(EGEM)[x>quantile(x,(1-th),na.rm=TRUE)],
                "reverse"=rownames(EGEM)[x<quantile(x,th,na.rm=TRUE)]))
  })
  names(lstSigs) <- colnames(EGEM)
  if(print){
    outfile <- file.path(outpath,paste("SigGenes",Sys.time(),".txt",sep=""))
    for(i in 1:length(lstSigs)){
      same <- lstSigs[[i]][["same"]]
      reverse <- lstSigs[[i]][["reverse"]]
      same <- matrix(c(same,rep("",10-length(same)%%10)),ncol=10,byrow=TRUE)
      same <- cbind(c("same",rep("",nrow(same)-1)),same)
      reverse <- matrix(c(reverse,rep("",10-length(reverse)%%10)),ncol=10,byrow=TRUE)
      reverse <- cbind(c("reverse",rep("",nrow(reverse)-1)),reverse)
    out <- rbind(same,reverse)
      cat(">",names(lstSigs)[i],"\n",file=outfile,append=TRUE)
      write.table(out,row.names=FALSE,col.names=FALSE,quote=FALSE,file=outfile,sep="\t",append=TRUE)
    }
  }
  return(lstSigs)
}



