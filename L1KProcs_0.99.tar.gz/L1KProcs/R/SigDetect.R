SigDetect <- function(egem.info,outpath="l1kanalysis",pNo=c(5:20),
                      repeatNo=30,nthread=1,
                      eta=-1, beta=0.01, lamda = -1,bi_conv=c(1e-3,5e-3),
                      keep=FALSE,wsize=10,print=TRUE,plot=TRUE,
                      TF=TRUE,cpdata=NULL,maPPI=NULL){
  ## checking matrix
  if(!file.exists(outpath))  dir.create(outpath)
  if(!file.exists(file.path(outpath,"tmpfiles")))  dir.create(file.path(outpath,"tmpfiles"))
  egem <- egem.info[["egem"]]
  PNames <- egem.info[["PNames"]]
  CNames <- egem.info[["CNames"]]
  lstcsNMF <- csNMF(egem.info,outpath,pNo,repeatNo,nthread,maPPI,
                    eta,beta,lamda,bi_conv,keep)
  sig.ids <- csNMF.No(lstcsNMF$egem,lstcsNMF$lstcsNMF,outpath)
  sig.names <- csNMF.report(sig.ids,CNames,PNames,outpath,wsize,print)
  var <- sig.names
  if(plot)
    csNMF.fig(lstcsNMF$egem,sig.ids,outpath)
  if(TF & is.null(cpdata)){
    sig.tfs <- csNMF.tf(sig.names,cpdata,outpath,wsize,print)
    var <- list(sig.names=sig.names, sig.tfs=sig.tfs)
  }
  return(var)
}

