csNMF.single <- function(upE,downE,maPPI,outpath="l1kanalysis",k,rN,
                         eta=-1, beta=0.01, lamda = -1,bi_conv=c(1e-3,5e-3),keep=FALSE){
  A <- upE
  A <- A[sample(rownames(A)),sample(colnames(A))]
  B <- downE
  B <- B[match(rownames(A),rownames(B)),match(colnames(A),colnames(B))]
  X <- cbind(A,B)
  Pp <- maPPI[match(rownames(A),rownames(maPPI)),match(rownames(A),colnames(maPPI))]
  tmp <- FuncsNMF(A,B,Pp, k, eta=eta, beta=beta, lamda=lamda,bi_conv=bi_conv)
  csNMF <- list()
  csNMF$W1 <- tmp$W1[match(rownames(upE),rownames(tmp$W1)),]
  csNMF$W2 <- tmp$W2[match(rownames(upE),rownames(tmp$W2)),]
  csNMF$H <- tmp$H[,match(colnames(upE),colnames(tmp$H))]

  if(keep){
    if(!file.exists(outpath)) dir.create(outpath)
    save(csNMF,file=file.path(outpath,paste("csnmf-",k,"-",rN,".rdata",sep="")))
  }
  return(csNMF)
}


csNMF <- function(egem.info,outpath="l1kanalysis",pNo=c(5:20),repeatNo=30,nthread=1,maPPI=NULL,
                  eta=-1, beta=0.01, lamda = -1,bi_conv=c(1e-3,5e-3),keep=FALSE){
  ## checking matrix
  if(!file.exists(outpath))  dir.create(outpath)
  ##  if(!file.exists(file.path(outpath,"tmpfiles")))  dir.create(file.path(outpath,"tmpfiles"))
  
  egem <- egem.info[["egem"]]
  PNames <- egem.info[["PNames"]]
  CNames <- egem.info[["CNames"]]
  minSize <- 5
  e1 <- apply(egem,1,function(x) sum(x!=0,na.rm=TRUE)>minSize)
  e2 <- apply(egem,2,function(x) sum(x!=0,na.rm=TRUE)>minSize)
  egem <- egem[e1,e2]
  PNames <- PNames[match(rownames(egem),names(PNames))]
  if(is.null(maPPI)){
  ## add PPI information
    newPPI <- get(data("newPPI",package="L1KProcs"))
    maPPI <- matrix(0,nrow=length(PNames),ncol=length(PNames))
    rownames(maPPI) <- names(PNames)
    colnames(maPPI) <- names(PNames)
    uKDgenes <- unique(PNames)
    uKDgenes <- paste(paste("^",uKDgenes,"$",sep=""),collapse="|")
    tmp <- newPPI[grep(uKDgenes,newPPI[,"item_id_a"]),]
    tmp <- tmp[grep(uKDgenes,tmp[,"item_id_b"]),]
    tmp[,"score"] <- tmp[,"score"]/1000
    kdPPI <- tmp
    lstgKDtarget <- split(PNames,PNames)
    for(gKDtarget in lstgKDtarget){
      maPPI[names(gKDtarget),names(gKDtarget)] <- 1
    }
    IDa <- lapply(lstgKDtarget[kdPPI[,1]],names)
    IDb <- lapply(lstgKDtarget[kdPPI[,2]],names)
    for( i in 1:length(IDa)){
      maPPI[IDa[[i]],IDb[[i]]] <- kdPPI[i,"score"]
    }
  }else{
    maPPI <- maPPI[e1,e1]
  }
  ## csNMF
  upE <- egem
  upE[upE<0] <- 0
  downE <- egem
  downE[downE>0] <- 0
  downE <- (-1)*downE

  
  lstcsNMF <- list()
  for(k in pNo){
    cl <- makeCluster(nthread)
    registerDoParallel(cl)
    clusterExport(cl, c("csNMF.single","FuncsNMF"))
    lstresult <- list()
    t <- 1
    while(t<=repeatNo){
      iStart <- t
      iEnd <- t+nthread-1
      if(iEnd>repeatNo) iEnd <- repeatNo
      o <- foreach(i=iStart:iEnd)%dopar%{
        res <- csNMF.single(upE,downE,maPPI,file.path(outpath,"tmpfiles"),k=k,rN=i,eta=eta, beta=beta, lamda = lamda,bi_conv=bi_conv,keep=keep)
      }
      lstresult <- unlist(list(lstresult,o),recursive=FALSE)
      t <- t+nthread
    }
    namek <- as.character(k)
    lstcsNMF[[namek]] <- lstresult
  }
  ##  names(lstcsNMF) <- pNo
  stopCluster(cl)
  ##  save(lstcsNMF,file=file.path(outpath,paste("lstcsNMF",min(pNo),max(pNo),"rda",sep=".")))
  var <- list(lstcsNMF=lstcsNMF,egem=egem,maPPI=maPPI)
  return(var)
}

sumM <- function(lstT){
  re <- matrix(0,nrow=nrow(lstT[[1]]),ncol=ncol(lstT[[1]]))
  for(t in lstT){
    re <- ifelse(is.na(re),t,ifelse(is.na(t),re,re+t))
  }
  return(re)
}

cosine <- function (x, y = NULL){
  ## This function is adopted from the function cosine of Package "lsa" in CRAN.
  ## Title Latent Semantic Analysis
  ## Version 0.63-3
  ## Date 2011-06-26
  ## Author Fridolin Wild
  ## Description The basic idea of latent semantic analysis (LSA) is, that text do have a higher order (=latent semantic) structure which,however, is obscured by word usage (e.g. through the use of synonyms or polysemy). By using conceptual indices that are derived statistically via a truncated singular value decomposition (a two-mode factor analysis) over a given document-term matrix, this variability problem can be overcome.
  ## Depends R (>= 2.10), Snowball, RWeka
  ## Maintainer Fridolin Wild <f.wild@open.ac.uk>
  ## License GPL (>= 2)
  ## Repository CRAN
  ## Date/Publication 2011-06-26 14:59:06
  ## Reference: Leydesdorff, L. (2005) Similarity Measures, Author Cocitation Analysis,and Information Theory}. In: JASIST 56(7), pp.769-772.
  
  if (is.matrix(x) && is.null(y)) {
    co = array(0, c(ncol(x), ncol(x)))
    f = colnames(x)
    dimnames(co) = list(f, f)
    for (i in 2:ncol(x)) {
      for (j in 1:(i - 1)) {
        co[i, j] = cosine(x[, i], x[, j])
        }
    }
    co = co + t(co)
    diag(co) = 1
    return(as.matrix(co))
    }
  else if (is.vector(x) && is.vector(y)) {
    return(crossprod(x, y)/sqrt(crossprod(x) * crossprod(y)))
    }
  else {
    stop("argument mismatch. Either one matrix or two vectors needed as input.")
  }
}


CalCos <- function(maT,maRef){
  maCos <- matrix(0,nrow=nrow(maT),ncol=nrow(maRef))
  for(ii in 1:nrow(maT)){
      for(jj in 1:nrow(maRef)){
        maCos[ii,jj] <- sum(maT[ii,]!=maRef[jj,])
      }
    }
  dimnames(maCos) <- list(seq(1:nrow(maT)),seq(1:nrow(maRef)))
  tmp <- as.data.frame(as.table(maCos))
  orderT <- tmp[order(tmp$Freq),]
  lsta <- seq(1:nrow(maT))
  lstb <- seq(1:nrow(maRef))
  orderA <- NULL
  orderB <- NULL
  for(ii in 1:nrow(orderT)){
      if(!is.element(orderT[ii,1],lsta)) next
      if(!is.element(orderT[ii,2],lstb)) next
      orderA <- c(orderA,orderT[ii,1])
      orderB <- c(orderB,orderT[ii,2])
      lsta <- lsta[-(which(lsta==orderT[ii,1]))]
      lstb <- lstb[-(which(lstb==orderT[ii,2]))]
    }
  cOrder <- cbind(orderA,orderB)
  cOrder <- cOrder[order(orderB),]
  re <- list()
  re[[1]] <- median(maCos[cOrder])
  re[[2]] <- cOrder[,1]
  return(re)
}

csNMF.No <- function(egem,lstcsNMF,outpath){
  upE <- egem
  upE[upE<0] <- 0
  downE <- egem
  downE[downE>0] <- 0
  downE <- (-1)*downE
  mu <- list()
  lstResult <- list()
  for(k in names(lstcsNMF)){
    W1 <- list()
    W2 <- list()
    H <- list()
    i <- 0
    for( result in lstcsNMF[[k]]){
      i <- i+1
      if(is.null(result)) next
      W1[[i]] <- result$W1
      W2[[i]] <- result$W2
      H[[i]] <- result$H
    }
    pH <- lapply(H,function(xH) t(apply(xH,1,function(x) 1-pnorm(x,mean(as.vector(xH),na.rm=TRUE),sd(as.vector(xH),na.rm=TRUE)))))
    tfH <- lapply(pH,function(x) x<0.025)
    pW1 <- lapply(W1,function(xW1) apply(xW1,2,function(x) 1-pnorm(x,mean(as.vector(xW1),na.rm=TRUE),sd(as.vector(xW1),na.rm=TRUE))))
    tfW1 <-  lapply(pW1,function(x) x<0.025)
    pW2 <- lapply(W2,function(xW2) apply(xW2,2,function(x) 1-pnorm(x,mean(as.vector(xW2),na.rm=TRUE),sd(as.vector(xW2),na.rm=TRUE))))
    tfW2 <-  lapply(pW2,function(x) x<0.025)


    tH <- list()
    tW1 <- list()
    tW2 <- list()
    ref <- cbind(tfH[[1]],t(tfW1[[1]]),t(tfW2[[1]]))
    tH[[1]] <- tfH[[1]]
    tW1[[1]] <- tfW1[[1]]
    tW2[[1]] <- tfW2[[1]]
    mode(ref) <- "numeric"
    lstcOrder <- list()
    lstcOrder[[1]] <- seq(1:nrow(tfH[[1]]))
    sumcons <- 0
    for( i in 2:length(tfH)){
      sth <-  cbind(tfH[[i]],t(tfW1[[i]]),t(tfW2[[i]]))
      mode(sth) <- "numeric"
      tmp <-  CalCos(sth,ref)
      lstcOrder[[i]] <- tmp[[2]]
      sumcons <- sumcons+tmp[[1]]
      tH[[i]] <- tfH[[i]][lstcOrder[[i]],]
      tW1[[i]] <- tfW1[[i]][,lstcOrder[[i]]]
      tW2[[i]] <- tfW2[[i]][,lstcOrder[[i]]]
    }
    sumcons <- sumcons/(i-1)

    thr <- floor(length(tH)/3)
    lstH <- apply( sumM(tH),1,function(x) colnames(H[[1]])[x>thr])
    lstW1 <- apply( sumM(tW1),2,function(x) rownames(W1[[1]])[x>thr])
    lstW2 <- apply( sumM(tW2),2,function(x) rownames(W2[[1]])[x>thr])

    t <- as.numeric(k)
    su <- matrix(0,nrow=(t+4),ncol=11)
    for( i  in 1:t){
      tmp <- c(as.vector(upE[c(lstW1[[i]]),lstH[[i]]]),as.vector(downE[c(lstW2[[i]]),lstH[[i]]]))
      tmp1 <- as.vector(upE[c(lstW1[[i]]),lstH[[i]]])
      tmp2 <- as.vector(upE[c(lstW2[[i]]),lstH[[i]]])
      su[i,1:6] <- summary(tmp)
      su[i,7] <- sd(tmp)
      su[i,8] <- sum(tmp==0)/length(tmp)^2
      su[i,9] <- sqrt(sum((tmp1-mean(tmp1))^2))/length(tmp1)^2+ sqrt(sum((tmp2-mean(tmp2))^2))/length(tmp2)^2
      su[i,10] <- sum(tmp)/length(tmp)^2
      su[i,11] <- sum(tmp1)/sd(tmp1)+sum(tmp2)/sd(tmp2)
    }
    su[(t+1),] <- apply(su[1:t,],2,sd,na.rm=TRUE)
    su[(t+2),] <- apply(su[1:t,],2,mean,na.rm=TRUE)
    su[(t+3),1:6] <- summary(as.vector(upE+downE))[1:6]
    su[(t+3),7] <- sd(as.vector(upE+downE))
    su[(t+4),1] <- sumcons
    mu[[k]] <- su
    lstResult[[k]] <- list(lstH,lstW1,lstW2)
  }

  names(mu) <- names(lstcsNMF)
  k <- names(which.min((unlist(lapply(mu,function(x) tail(x,1)[1])))))
  save(lstResult,file=file.path(outpath,"lstResult.rdata"))
  save(mu,file=file.path(outpath,"mu.rdata"))

### Parameter: lstC lstP1 lstP2 k 
  result <- lstResult[[k]]
  k <- as.numeric(k)
  lstC <- result[[1]]
  lstP1 <- result[[2]]
  lstP2 <- result[[3]]
  delID <- unique(c(which(unlist(lapply(lstC,length))<3),which((unlist(lapply(lstP1,length)) +unlist(lapply(lstP1,length)))<3)))
  if(length(delID)){
    k <- k-length(delID)
    lstC <- lstC[-delID] 
    lstP1 <- lstP1[-delID]
    lstP2 <- lstP2[-delID]
  }
  result <- list(k=k,lstC=lstC,lstP1=lstP1,lstP2=lstP2)
  result <- csNMF.No.modified(egem,result)
  return(result)
}


csNMF.No.modified <- function(egem,sig.ids){
  th <- 0.05
  upE <- egem
  upE[upE<0] <- 0
  downE <- egem
  downE[downE>0] <- 0
  downE <- (-1)*downE

  lstP1 <- sig.ids[["lstP1"]]
  lstP2 <- sig.ids[["lstP2"]]
  lstC <- sig.ids[["lstC"]]
  pNo <- sig.ids[["k"]]
  delID <- NULL
  
  index <- c(mean(as.vector(upE),na.rm=T),sd(as.vector(upE),na.rm=T),mean(as.vector(downE),na.rm=T),sd(as.vector(downE),na.rm=T))
  for(k in 1:pNo){
    subE1 <- egem[lstP1[[k]],lstC[[k]]]
    subE2 <- (-1)*egem[lstP2[[k]],lstC[[k]]]
    if(length(lstC[[k]])==1){
      lstP1[[k]] <- lstP1[[k]][1-pnorm(subE1,index[1],index[2])<th] 
      lstP2[[k]] <- lstP2[[k]][1-pnorm(subE2,index[3],index[4])<th]
    }else{
      lstP1[[k]] <- lstP1[[k]][1-pnorm(apply(subE1,1,mean),index[1],index[2])<th]
      lstP2[[k]] <- lstP2[[k]][1-pnorm(apply(subE2,1,mean),index[3],index[4])<th]
    }
    subE <- egem[c(lstP1[[k]],lstP2[[k]]),lstC[[k]]]
    if(is.null (subE)){
      delID <- c(delID,k)
      next
    }
    rande = (unlist(lapply(1:1000,function(t){
      a <- suppressWarnings(cor(egem[sample(rownames(egem),nrow(subE)),sample(colnames(egem),2)]))
      a <- a[upper.tri(a)]
      return(a)
    })))
    e <- suppressWarnings(cor(subE,use="na.or.complete"))
    while(1){
      me <- unlist(lapply(1:nrow(e),function(i)median(e[i,-i],na.rm=T)))
      if(1-pnorm(min(me),mean(rande,na.rm=T),sd(rande,na.rm=T))<2*th){
        break
      }
      e <- e[-which.min(me),-which.min(me)]
      if(is.null(e)) break
    }
   
    p.value <- 1-pnorm(me,mean(rande,na.rm=T),sd(rande,na.rm=T))
    if(!sum(p.value<2*th)){
      delID <- c(delID,k)
      next
    }
    lstC[[k]] <- colnames(e)[p.value<(2*th)]
  }
  if(length(delID)){
    lstC <- lstC[-delID]
    lstP1 <- lstP1[-delID]
    lstP2 <- lstP2[-delID]
  }

  result.modify <- list(k=k,lstC=lstC,lstP1=lstP1,lstP2=lstP2)
  return(result.modify)
}  

csNMF.report <- function(sig.ids,CNames,PNames,outpath,wsize=10,print=TRUE){
  lstP1 <- sig.ids[["lstP1"]]
  lstP2 <- sig.ids[["lstP2"]]
  lstC <- sig.ids[["lstC"]]
  pNo <- sig.ids[["k"]]
  SigCNames <- lapply(lstC,function(x) {
    tmp <- CNames[x]
    names(tmp) <- x
    return(tmp)
  })
  SigPNames1 <- lapply(lstP1,function(x) {
    tmp <- PNames[x]
    names(tmp) <- x
    return(tmp)
  })
  SigPNames2 <- lapply(lstP2,function(x) {
    tmp <- PNames[x]
    names(tmp) <- x
    return(tmp)
  })
  lstClen <- lapply(lstC,length)
  lstP1len <- lapply(lstP1,length)
  lstP2len <- lapply(lstP2,length)
  if(print){
    outfile <- file.path(outpath,"SigReports.txt")
    if(file.exists(outfile))
      file.remove(outfile)
    cat("Signature Report\n",file=outfile,append=TRUE)
    cat("SigNo: ",pNo,"\n","CompoundNo: ",paste(lstClen,sep=","),"\n",
        "Siggene:sameNo: ", paste(lstP1len,sep=","),"\n",
      "Siggene:sameNo: ", paste(lstP2len,sep=","),"\n",file=outfile)
    
    for(k in 1:pNo){
      cat("> Sig",k,"\n",file=outfile,append=TRUE)
      tmp <- matrix(c(SigCNames[[k]],rep("",wsize-length(SigCNames[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("Compounds",rep("",nrow(tmp)-1)),tmp)
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
      tmp <- matrix(c(SigPNames1[[k]],rep("",wsize-length(SigPNames1[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("SigGenes:same",rep("",nrow(tmp)-1)),tmp)
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
      tmp <- matrix(c(SigPNames2[[k]],rep("",wsize-length(SigPNames2[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("SigGenes:reverse",rep("",nrow(tmp)-1)),tmp)
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
    }
    cat("Signature report using Perturbagen IDs\n",file=outfile,append=TRUE)
    for(k in 1:pNo){
      cat("> Sig",k,"\n",file=outfile,append=TRUE)
      tmp <- matrix(c(lstC[[k]],rep("",wsize-length(lstC[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("Compounds",rep("",nrow(tmp)-1)),tmp)    
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
      tmp <- matrix(c(lstP1[[k]],rep("",wsize-length(lstP1[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("SigGenes:same",rep("",nrow(tmp)-1)),tmp) 
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
      tmp <- matrix(c(lstP2[[k]],rep("",wsize-length(lstP2[[k]])%%wsize)),ncol=wsize)
      tmp <- cbind(c("SigGenes:reverse",rep("",nrow(tmp)-1)),tmp)    
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
    }
  }
  sig.names <- list(k=pNo,SigCNames=SigCNames,SigPNames1=SigPNames1,SigPNames2=SigPNames2)
  return(sig.names)
}


csNMF.fig <- function(egem,sig.ids,outpath){
  lstP1 <- sig.ids[["lstP1"]]
  lstP2 <- sig.ids[["lstP2"]]
  lstC <- sig.ids[["lstC"]]
  pNo <- sig.ids[["k"]]

  uC <- table(unlist(lstC))
  lstuC <- lapply(lstC,function(x) x[uC[match(x,names(uC))]==1])
  
  clen <- unlist(lapply(1:pNo,function(x) length(unique(unlist(lstuC[1:x])))))
  clen <- c(1,clen)

  corder <- unlist(lstuC)

  uP <- table(c(unlist(lstP1),unlist(lstP2)))
  lstuP1 <- lapply(lstP1,function(x) x[uP[match(x,names(uP))]==1])  
  lstuP2 <- lapply(lstP2,function(x) x[uP[match(x,names(uP))]==1])  
  lstuP <- lapply(1:pNo,function(x) c(lstuP1[[x]],lstuP2[[x]]))
  lstlen <- c(0,unlist(lapply(lstuP,length)))
  uporder <- unlist(lstuP)
  
  vecmark <- vector()
  dporder <- vector()
  lstP <- unlist(list(lstP1,lstP2),recursive=FALSE)
  for(k in 1:pNo){
    plist1 <- lstP1[[k]][!(lstP1[[k]]%in%dporder)]
    plist2 <- lstP2[[k]][!(lstP2[[k]]%in%dporder)]
    porder1 <- vector()
    while(1){
      plist1 <- plist1[!(plist1%in%porder1)]
      plist2 <- plist2[!(plist2%in%porder1)]
      if(!length(plist1) & !length(plist2)) break
      tmp1 <- lapply(lstP,function(x) intersect(plist1,x))
      tmp2 <- lapply(lstP,function(x) intersect(plist2,x))
      tmp <- unlist(list(tmp1,tmp2),recursive=FALSE)
      deli <- which.max(unlist(lapply(tmp,length)))
      porder1 <- c(porder1,tmp[[deli[1]]])
    }
    dporder <- c(dporder,porder1)
    vecmark[k] <- length(porder1)
  }
  
  subE <- egem[c(uporder,dporder),corder]
  if(length(c(uporder,dporder))<2) return()
  subE1 <- egem[dporder,corder]
  rid0 <- nrow(subE)-cumsum(lstlen)
  subE<<-subE
  lstlen<<-lstlen
  clen[1] <- clen[1]-1
  clen<<-clen+0.5
  rid0<<-rid0+0.5
  pNo <<- pNo
  subE1<<-subE1
  lstP1<<-lstP1
  lstP2<<-lstP2
  
  pdf(file.path(outpath,"Signatures.pdf"))

  heatmap.2(subE,col="greenred",trace="none",Rowv=F,Colv=F,
            labCol="",labRow="",dendrogram="none",breaks=seq(-0.5,0.5,0.01),
            add.expr={
              abline(h=nrow(subE)-sum(lstlen),lwd=1,col="white")
              for(k in 1:pNo){
                rect(clen[k],rid0[k+1],clen[k+1],rid0[k],lwd=1.5,border="yellow")
                ids <- nrow(subE)-sum(lstlen)-which(!is.na(match(rownames(subE1),c(lstP1[[k]],lstP2[[k]]))))
                inval <- ids[1:length(ids)-1]-ids[2:length(ids)]
                ids1 <- c(1,which(inval>nrow(subE)*0.005),length(inval))
                inval1 <- ids1[2:length(ids1)]-ids1[1:length(ids1)-1]
                ids2 <- which(inval1>nrow(subE)*0.005)
                rid <- ids[ids1[unlist(rbind(ids2,ids2+1))]+1]
                if(length(rid)){
                  for( i in seq(1,length(rid),2)){
                    rect(clen[k],rid[i+1],clen[k+1],rid[i],lwd=1.5,border="yellow")
                  }
                }
              }})
  title(xlab="Compound",cex.lab=1.5,mgp=c(2,1,0));
  title(ylab="Genes",cex.lab=1.5,mgp=c(-2,-3,0));
  title(main="Signatures     ",cex.main=3,adj=1,mgp=c(-2,-3,0));
  garbage <-dev.off()
}

csNMF.tf <- function(sig.names,cpdata,outpath=NULL,wsize=10,print=TRUE){
  triplets <- get(data("triplets",package="L1KProcs"))
  genelist <- rownames(cpdata)

  pNo <- sig.names[["k"]]
  lstCNames <- sig.names[["SigCNames"]]
  lstPNames1 <- sig.names[["SigPNames1"]]
  lstPNames2 <- sig.names[["SigPNames2"]]

  cpfull <- ConvertM(expM=cpdata)

  meanD <- mean(as.vector(cpfull),na.rm=TRUE)
  sdD <- sd(as.vector(cpfull),na.rm=TRUE)
  lstDEG <- lapply(lstCNames,function(x) DEG(cpfull[,names(x)],meanD=meanD,sdD=sdD))

  libdeg <- list()
  for(k in 1:pNo){
    len <- length(lstDEG[[k]][["up"]])
    up <- table(unlist(lstDEG[[k]][["up"]])) 
    down <- table(unlist(lstDEG[[k]][["down"]]))
    libdeg[[k]] <- c(genelist[which(up>len/3)],genelist[which(down>len/3)])
  }

  tf <- list()
  for(k in 1:pNo){
    cm <- c(lstPNames1[[k]],lstPNames2[[k]])
    ctf1 <- triplets[na.omit(match(cm,triplets[,"modulator"])),]
    ctf2 <- triplets[na.omit(match(cm,triplets[,"tf"])),] 
    ctf3 <- triplets[na.omit(match(cm,triplets[,"genes"])),] 
    tf[[k]] <- triplets[na.omit(match(libdeg[[k]],triplets[,"genes"])),]
  }
  tfs <- lapply(tf,function(x){
    if(length(x)==3) return(unique(x["tf"]))
    return(unique(x[,"tf"]))})
  tfs <- lapply(tfs,function(x) as.character(na.omit(x)))

  if(print & !is.null(outpath)){
    outfile <- file.path(outpath,"SigTranscriptFactors.txt")
    if(file.exists(outfile))
      file.remove(outfile)
    cat("Signature Related Transcription Factors\n",file=outfile,append=TRUE)
    for(k in 1:pNo){
      cat("> Sig",k,"\n",file=outfile,append=TRUE)
      tmp <- matrix(c(tfs[[k]],rep("",wsize-length(tfs[[k]])%%wsize)),ncol=wsize)
      write.table(tmp,file=outfile,col.names=FALSE,row.names=FALSE,sep="\t",append=TRUE,quote=FALSE)
    }
  }
  return(tfs)
}
