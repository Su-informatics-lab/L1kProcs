Quality.Cons <- function(platename,mctrs,pth=0.5,wth=0.6,dupplates=NULL,outpath){
  ## Plate based control
  QNData <- ReadQNData(platename,outpath)
  ControlList <- na.omit(match(mctrs,colnames(QNData)))
  QNControl <- QNData[ControlList]
  if(length(ControlList)<2) {
    corCs <- matrix(nrow=0,ncol=0)
    ifpq <- TRUE
  }else{
    corCs <- cor(QNControl,use="na.or.complete")
    ifpq <-ifelse(median(corCs[upper.tri(corCs)],na.rm=T)<pth,FALSE,TRUE)
  }
  ## Well based control
  duplen <- length(dupplates)-1
  if(duplen==0){
    covwells <- rep(1,length=(ncol(QNData)-3))
    names(covwells) <- colnames(QNData)[4:ncol(QNData)]
  }else{
    lstQNData <- do.call(cbind,lapply(dupplates,function(dup){
      return(ReadQNData(dup,outpath))
    }))
    lstWells <- unlist(lapply(strsplit(colnames(lstQNData),"_"),function(x) x[length(x)]))
    lstdups <- split(colnames(lstQNData),lstWells)
    covwells <- unlist(lapply(colnames(QNData)[4:ncol(QNData)],function(x){
      pwell <-unlist(strsplit(x,"_"))
      pwell <- pwell[length(pwell)]
      if(length(lstdups[[pwell]])<2) return(1)
      wellcov <- cor(lstQNData[,lstdups[[pwell]]],use="na.or.complete")
      return((sum(wellcov[x,])-1)/duplen)
    }))
  }
  covwells.2 <- (covwells>wth)
  covwells.2 <- data.frame(covwells = covwells, ifwq=covwells.2)
  rownames(covwells.2) <- colnames(QNData)[4:ncol(QNData)]
  return(list(covcontrol=corCs,ifquality=ifpq,covwells = covwells.2))
}

QualityControl <- function(outpath="l1kdata",lstControls=NULL,pth=0.5,wth=0.6,lstPlates=NULL,lstdupPlates=NULL,nthread=1,check=TRUE){
  if(check){
    if(is.null(lstPlates)){
      file <- file.path(outpath,"data_summary","lstPlates.rda")
      if(file.exists(file)){
        load(file)
      }else{
        stop("lstPlates is not specified.")
      }
    }
    if(!file.exists(outpath)){
      stop( outpath, "is not a valid path.")
    }
    if(nthread<1){
      warning("Number must be positive!. Process with no parallel!.")
      nthread <- 1
    }
  }
  
  cl <- makeCluster(nthread)
  registerDoParallel(cl)
  clusterExport(cl, c("Quality.Cons","ReadQNData"))
  Nerrs <- list()
  k <- 1
  while( k <length(lstPlates)){
    iStart <- k
    iEnd <- k+nthread-1
    if(iEnd>length(lstPlates)) iEnd <- length(lstPlates)
    Nerrs[[k]] <- foreach(i=iStart:iEnd) %dopar% {
      mctrs <- lstControls[[i]]
      return(Quality.Cons(lstPlates[i],mctrs,pth=pth,wth=wth,dupplates=lstdupPlates[[i]],outpath))
    }
    k <- k+nthread
  }
  quality <- unlist(Nerrs,recursive=FALSE)
  names(quality) <- lstPlates
  stopCluster(cl)
  return(quality)
}


