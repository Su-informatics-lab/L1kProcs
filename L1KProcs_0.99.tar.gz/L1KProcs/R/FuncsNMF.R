#######################################################
## The program of csNMF is adopted and modified  from the function of NMF package.
## Reference: Renaud Gaujoux, Cathal Seoighe (2010). A flexible R package for nonnegative matrix factorization. BMC Bioinformatics 2010, 11:367.
######################################################

fcnnls_W <- function (A,W1,W2,H,Dp,Pp,eta, beta, lamda){
  AHt <- crossprod(t(A),t(H))
  PW <- crossprod(Pp,(W1+W2))
  HHt <- crossprod(t(H),t(H))
  WHHt <- crossprod(t(W1),HHt)
  DW <- crossprod(Dp,(W1+W2))
  
  changeW <- (AHt+lamda*PW)/(WHHt+eta*W1+lamda*DW)
  newW <- W1*changeW
  res <- newW
  return(res)
}


fcnnls_H <- function (A1,A2,W1,W2,H, beta){
  WtA1 <- crossprod(W1,A1)
  WtA2 <- crossprod(W2,A2)
  WtWH1 <- crossprod(W1,W1)%*%H
  WtWH2 <- crossprod(W2,W2)%*%H

  k <- nrow(H)
  n <- ncol(H)
  betaH <- t(matrix(rep(t(beta*apply(H,2,sum)),k),nrow=n,ncol=k))
  
  changeH <- (WtA1+WtA2)/(WtWH1+WtWH2+betaH)
  newH <- H*changeH
  res <- newH
  return(res)
}


## M. H. Van Benthem and M. R. Keenan, J. Chemometrics 2004; 18: 441-450
##
## Given A and C this algorithm solves for the optimal 
## K in a least squares sense, using that
##      A = C*K 
## in the problem
##      min ||A-C*K||, s.t. K>=0, for given A and C.
##
##
## @param C the matrix of coefficients
## @param A the target matrix of observations
##
## @return [K, Pset]
##

##
## csNMF: PPI constraint to sNMF/R  
##
## This method is based on the sNMF/R method proposed by Kim et.al..
## The constraint of the coef matrix H is based on the protein protein interaction
##
## sNMF/R Author: Hyunsoo Kim and Haesun Park, Georgia Insitute of Technology
##
## Reference: 
##
##   Sparse Non-negative Matrix Factorizations via Alternating 
##   Non-negativity-constrained Least Squares for Microarray Data Analysis
##   Hyunsoo Kim and Haesun Park, Bioinformatics, 2007, to appear.
##
##
## NMF: min_{W,H} (1/2) || A - WH ||_F^2 s.t. W>=0, H>=0 
## csNMF: sNMF with additional constraints on H based on Protein-Protein Interaction(PPI)
##
##   min_{W,H} (1/2) (|| A - WH ||_F^2 + eta ||W||_F^2 
##                + beta (sum_(j=1)^n ||H(:,j)||_1^2))
##                + lamda*tr(t(W)*(D-P)*W)
##                s.t. W>=0, H>=0 
##
## A: m x n data matrix (m: features, n: data points)
## W: m x k basis matrix
## H: k x n coefficient matrix
## P: n x n PPI symmetric matrix
## D: n x n diagonal matrix, each non-zero element is the sum of the values of its row
## D-P :    Laplacian matrix when P is a incidence matrix
##
## function [W,H,i]=FuncsNMF(A1,A2,Pp,k,param,verbose,bi_conv,eps_conv)
##
## input parameters:
##   A1: m x n data matrix (m: features, n: data points)
##   A2: m x n data matrix (m: features, n: data points)
##   Pp: m x m data matrix (m: features)
##   k: desired positive integer k
##   param=[eta beta lamda]:  
##      eta (for supressing ||W||_F)
##         if eta < 0, software uses maxmum value in A as eta. 
##      beta (for sparsity control)
##         Larger beta generates higher sparseness on H.
##         Too large beta is not recommended.
##      lamda ( for constrain elements of H )
##         Larger lamda generates H more coordinate with input PPI scores
##         Too large lamda will miss the information from the gene expression
##   verbos: verbose = 0 for silence mode, otherwise print output
##   eps_conv: KKT convergence test (default eps_conv = 1e-4)
##   bi_conv=[wminchange iconv] biclustering convergence test 
##        wminchange: the minimal allowance of the change of 
##        row-clusters  (default wminchange=0)
##        iconv: decide convergence if row-clusters (within wminchange)
##        and column-clusters have not changed for iconv convergence 
##        checks. (default iconv=10)
##
## output:
##   W: m x k basis matrix
##   H: k x n coefficient matrix
##   i: the number of iterations
##
##
## 
#function [W,H,i] 
FuncsNMF <- function(A1,A2,Pp,k,eta=-1, beta=0.01, lamda = -1, bi_conv=c(1e-5,1e-5), eps_conv=1e-6,iconv=5, verbose=TRUE){

  maxiter = 10000; # maximum number of iterations
  m = nrow(A1); n = ncol(A1); erravg = numeric();

  maxA=max(A1); if ( eta<0 ) eta=maxA;
  eta2=eta^2;
  if(lamda <0) lamda <- mean(c(as.vector(A1),as.vector(A2)),na.rm=TRUE)
  ## bi_conv
  if( length(bi_conv) != 2 )
    stop("csNMF:Invalid argument 'bi_conv' - value should be a 2-length numeric vector")
  wminchange=bi_conv[1]; hminchange=bi_conv[2];
  Dp <- diag(apply(Pp,1,sum))

  
  ## Validity of parameters
  ## eps_conv
  if( eps_conv <= 0 )
    stop("csINMF:Invalid argument 'eps_conv' - value should be positive")
  ## wminchange
  if( wminchange < 0 )
    stop("csNMF:Invalid argument 'bi_conv' - bi_conv[1] (i.e 'wminchange') should be non-negative")
  ## iconv
  if( iconv < 0 )
    stop("csNMF:Invalid argument 'bi_conv' - bi_conv[2] (i.e 'iconv') should be non-negative")
  ## beta
  if( beta <=0 )
     stop("csNMF:Invalid argument 'beta' - value should be positive")
  if (lamda <=0 ){
    warning("csNMF: Not a positive 'lamda' value, no constraint of W based on PPI")
    lamda = 0
  }
  if ( verbose )
    message(sprintf("--\nAlgorithm: csNMF\nParameters: k=%d eta=%.2e beta (for sparse H)=%.2e lamda (for constraint of W) =%.2e wchange=%.2e hchange=%.2e,eps_conv=%.2e,iconv=%s\n",
                k,eta,beta,lamda,wminchange,hminchange,eps_conv,iconv));

##  idxW1old=rep(0, m);idxW2old=rep(0, m); idxHold=rep(0, n);

  inc=0;	
  
  ## initialize random W if no starting point is given
  W1=matrix(runif(m*k), m,k);
  W2=matrix(runif(m*k), m,k);
  ## check validity of seed
  if( any(NAs <- is.na(W1)) )
    W1[is.na(W1)] <- 0
  if( any(NAs <- is.na(W2)) )
    W2[is.na(W2)] <- 0
  I_k=diag(eta, k); betavec=rep(sqrt(beta), k); nrestart=0;	
  H=matrix(runif(k*n), k,n);	
  
  for ( i in 1:maxiter ){
    res = fcnnls_H(A1,A2,W1,W2,H,beta)
    pH=H
    H = res
    if ( any(apply(H,2,sum,na.rm=TRUE)==0)){ 	  
      if( verbose ) message(sprintf("iter%d: 0 row in H eta=%.4e restart %d times!\n",i,eta,nrestart));
      lst= list(W1=W1,A1=A1,A2=A2,H=H,beta=beta)
      save(lst,file="lst.rda")
      nrestart=nrestart+1;
      if ( nrestart >= 10 ){
        warning("csNMF - Too many restarts due to too big 'beta' value [Computation stopped after the 9th restart]");
        return(NULL)
      }
      ## re-initialize random W
##      idxW1old=rep(0, m);idxW2old=rep(0, m); idxHold=rep(0, n);
      inc=0; 
      erravg <- numeric();## re-initialize base average error
      W1=matrix(runif(m*k), m,k);
      W2=matrix(runif(m*k), m,k);
      H=matrix(runif(k*n), k,n);	
      i = 1
      next;
    }
    ## min_w ||A-WH||+eta||W||+lamda*tr(t(W)*(D-P)*W), s.t. W>=0, for given A and H. 
    res = fcnnls_W(A1,W1,W2,H,Dp,Pp,eta, beta, lamda);
    pW1=W1
    pW2=W2
    W1 = res
    res = fcnnls_W(A2,W2,W1,H,Dp,Pp,eta, beta, lamda);
    W2 = res
    ## test convergence every 5 iterations OR if the base average error has not been computed yet
    if ( (i %% 5==0)  || (length(erravg)==0) ){
      ## indice of maximum for each row of W
  ##    idxW1 = max.col(W1)
  ##    idxW2 = max.col(W2)
      ## indice of maximum for each column of H
 ##     idxH = max.col(t(H))
      changedW1=abs(W1 - pW1);
      changedW2=abs(W2 - pW2);
      changedH=abs(H - pH);
      sumerrW1=sum(changedW1,na.rm=TRUE)
      sumerrW2=sum(changedW2,na.rm=TRUE);
      sumerrH=sum(changedH,na.rm=TRUE);
      maxerrW1=max(changedW1,na.rm=TRUE)
      maxerrW2=max(changedW2,na.rm=TRUE);
      maxerrH=max(changedH,na.rm=TRUE);
      
      if ( (maxerrW1<=wminchange)&(maxerrW2<=wminchange) & (maxerrH<=hminchange) ) inc=inc+1
      else inc=0
      ## compute base average error if necessary
      erravg = ((sumerrW1+sumerrW2)/(sum(pW1)+sum(pW2))+sumerrH/(sum(pH)))/2
      errmax = max(maxerrW1,maxerrW2,maxerrH)
      if ( verbose && (i %% 1000==0) ){ ## prints number of changing elements
        message(sprintf("\t%d\t%d\t---\tmaxerrW1: %.3e\tmaxerrW2: %.3e\tmaxerrH: %.3e\terravg: %.3e\n",
                    i,inc,maxerrW1,maxerrW2,maxerrH,erravg));
      }
      ##print(list(inc=inc, iconv=iconv, erravg=erravg, eps_conv=eps_conv, erravg=erravg))
      if ( (inc>=iconv) && (erravg<=eps_conv) ){
        message(sprintf("\t%d\t%s\t---\tmaxerrW1: %.3e\tmaxerrW2: %.3e\tmaxerrH: %.3e\terravg: %.3e\n",
                    i,inc,maxerrW1,maxerrW2,maxerrH,erravg));
        break;
      }
      ##        idxW1old=idxW1; idxW2old=idxW2; idxHold=idxH; 
    }

  }
  if( verbose ) message("--\n")
  res <- list(W1=W1,W2=W2, H=H)
  ##  str(res)
  return(res)
}

## ## Computes the objective value for the csNMF algorithm
## csnmf.objective <- function(target, w, h, p, dp, eta, beta,lamda){
##   subn <- ncol(target)/2
##   target1 <- target[,1:subn]
##   target2 <- target[,(subn+1):ncol(target)]
##   subnw <- ncol(w)/2
##   w1 <- w[,1:subnw]
##   w2 <- w[,(subnw+1):ncol(w)]
##   1/2 * ( sum( (target1 - (w1 %*% h))^2 )
##          +sum( (target2 - (w2 %*% h))^2 ) 
##          + eta * sum(w1^2)
##          + eta * sum(w2^2)
##          + beta * sum( apply( h,2,sum )^2 )
##          +lamda * sum(diag(t(w1+w2)%*%(dp-p)%*%(w1+w2)))
##          )
## }






