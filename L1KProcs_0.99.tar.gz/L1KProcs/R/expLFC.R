##########################################################
## L1K Data log fold change
##
## The function is to generate log fold change gene expression data.
##
## Paramters
## lstPlates: a vector of plate names.
## lstControls: a vector of control list.
## control.excludes: a vector of wells names not included as controls, when lstControls=NULL.
## control.specify: user specified control type, when lstControls=NULL..
## outpath: the path where to put all the processed data and their information.
## nthread: parallel number. [Default=1]
## overwrite: if overwrite existing files. [Default=FALSE]
## check: FALSE only for inner use.
## Outpath
## [platename]_LFC.gct
## They are stored in the folder outpath. 

expLFC <- function(lstPlates=NULL,lstControls=NULL,control.excludes=NULL,control.specify=NULL,outpath="l1kdata",nthread=1,overwrite=FALSE,check=TRUE){
  if(check){
    if(is.null(lstPlates)){
      if(!CheckData(outpath)){
        DataStorage.2(outpath)}
      load(file.path(outpath, "data_summary","lstPlates.rda"))
    }
    if(nthread<1){
      warning("Number must be positive!. Process with no parallel!.")
      nthread <- 1
    }
    if(is.null(lstControls)){
      PlateMap <- get(data("PlateMap",package="L1KProcs",envir=.GlobalEnv))
      l1kControls <- get(data("l1kControls",package="L1KProcs",envir=.GlobalEnv))
      lstControls <- lapply(lstPlates,function(PlateName){
        lstctr.info <- FindControls(PlateName,PlateMap,l1kControls,
                                    control.excludes=control.excludes,
                                    control.specify=control.specify)
        controls <- lstctr.info[["controls"]]
        majorctr <- lstctr.info[["majorctr"]]
        return(controls[controls==majorctr])
      })
    }
  }
  
  if(nthread==1){
    Nerrs <- list()
    for(i in 1:length(lstPlates)){
      o <- QN2LFC(lstPlates[i], outpath,
                         lstControlWells=lstControls[[i]],
                         overwrite=overwrite)
    }
  }else{
    if(length(lstPlates)<nthread) nthread <- length(lstPlates)
    cl <- makeCluster(nthread)
    registerDoParallel(cl)
    clusterExport(cl, c("QN2LFC","ReadGCT","ReadQNData","ModeShortName","ParseDataName","WriteGCT"))
    k <- 1
    while( k <length(lstPlates)){
      iStart <- k
      iEnd <- k+nthread-1
      if(iEnd>length(lstPlates)) iEnd <- length(lstPlates)
      o <- foreach(i=iStart:iEnd) %dopar% {
        QN2LFC(lstPlates[i], outpath,
               lstControlWells=lstControls[[i]],   
               overwrite=overwrite)
      }
      k <- k+nthread
    }
    stopCluster(cl)
  }
}

