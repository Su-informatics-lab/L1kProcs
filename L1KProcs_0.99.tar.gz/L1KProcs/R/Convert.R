##########################################################
## L1K Data Converting the gene expression of landmark genes to all genes.
##
## The function is to convert gene expression of landmark genes to all genes, expression includesraw, normalized, and log fold change gene expression data.
##
## Paramters
## platefile: the list of plate names.
## outpath: the path where to put all the processed data and their information.
## nthread: parallel number. [Default=1]
## overwrite: if overwrite existing files. [Default=FALSE]
## Outpath
## [platename]_Raw_full.gct
## [platename]_full.gct
## [platename]_LFC_full.gct
## They are stored in the folder outpath. 
########################################
#            ConvertM                #
########################################
ConvertM <- function(inGCT=NULL,expM=NULL,refmatrix=NULL,outpath="l1kdata",overwrite=FALSE,check=TRUE){
  if(check){
    if(is.null(expM)){
      if(is.null(inGCT)){
        warning("Input GCT file path must be specified")
        return()
      }else if(!file.exists(inGCT)){
        warning(paste(inGCT,"does not exist!"))
        return()
      }
      if(length(grep(".gct",inGCT))==0){
        warning(paste(inGCT,"is not a GCT file."))
        return()
      }
    }else if(!is.matrix(expM)){
      warning("expM should be a matrix.")
      return()
    }
    if(is.null(refmatrix)){
      refmatrix <- get(data("CMatrix",package="L1KAnno"))
      refmatrix <- refmatrix$refmatrix
    }
  }else{
    if(!file.exists(inGCT)){
      warning(paste(inGCT,"does not exist!"))
      return()
    }
  }
  if(is.null(expM)){
    tmp <- unlist(strsplit(inGCT,"[.]"))
    ofGCT <- paste(paste(tmp[1:(length(tmp)-1)],collapse="."),"full.gct",sep="_")
    if(file.exists(ofGCT)){
      if(overwrite){
        file.remove(ofGCT)
      }else{
        message(ofGCT, " exists.Skip.")
        return()
      }
    }
    GCT <- read.delim(inGCT,sep="\t",stringsAsFactors=FALSE,skip=2)
    Exp <- as.matrix(GCT[,4:ncol(GCT)])
    mode(Exp) <- "numeric";
    rownames(Exp) <- GCT[,1]
  }else{
    Exp <- expM
  }
  refn <- as.matrix(refmatrix[,4:ncol(refmatrix)])
  refn[is.na(refn)] <- 0
  rownames(refn) <- refmatrix[,1]

  expFull <- refn[,match(rownames(Exp),colnames(refn))]
  maexp <- expFull%*%Exp
  if(is.null(exp)){
    rownames(maexp) <- NULL
    GCTData <- cbind(refmatrix[,c(2,1,3)],maexp)
    colnames(GCTData) <- colnames(GCT)
    GCTData <- rbind(GCT,GCTData)
    if(ncol(maexp) ==1)
      colnames(GCTData)[4] <- colnames(GCT)[4]
    WriteGCT(GCTData,ofGCT)
  }else{
    GCTData <- rbind(Exp,maexp)
    return(GCTData)
  }
}


ConvertExp <- function(lstPlates=NULL,outpath="l1kdata",nthread=1,overwrite=FALSE,check=TRUE){
  if(check){
    if(is.null(lstPlates)){
      tmp <- file.path(outpath, "data_summary","lstPlates.rda")
      if(!file.exists(tmp))
        DataStorage.2(outpath)
      load(tmp)
    }
    if(!file.exists(file.path(outpath, "data_summary"))) dir.create(file.path(outpath, "data_summary"))                                                                             
  }
  
  CMatrix <- get(data("CMatrix",package="L1KAnno"))
  CMatrix <- CMatrix$refmatrix
  if(nthread==1){
    for(i in 1:length(lstPlates)){
      ProbeName <- ParseDataName(paste(lstPlates[i],"_A01",sep=""))["ShortModeID",]
      inGCT1 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,"_Raw.gct",sep="")
      ConvertM(inGCT=inGCT1,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
      inGCT2 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,".gct",sep="")
      ConvertM(inGCT=inGCT2,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
      inGCT3 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,"_LFC.gct",sep="")
      ConvertM(inGCT=inGCT3,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
    }
  }else{
    if(nthread>length(lstPlates )) nthread <- length(lstPlates)
    cl <- makeCluster(nthread)
    registerDoParallel(cl)
    clusterExport(cl, c("ParseDataName","ConvertM"))
    k <- 1
    while( k <length(lstPlates)){
      iStart <- k
      iEnd <- k+nthread-1
      if(iEnd>length(lstPlates)) iEnd <- length(lstPlates)
      o <- foreach(i=iStart:iEnd) %dopar% {
        ProbeName <- ParseDataName(paste(lstPlates[i],"_A01",sep=""))["ShortModeID",]
        inGCT1 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,"_Raw.gct",sep="")
        ConvertM(inGCT=inGCT1,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
        inGCT2 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,".gct",sep="")
        ConvertM(inGCT=inGCT2,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
        inGCT3 <- paste(outpath,"/",lstPlates[i],"_",ProbeName,"_LFC.gct",sep="")
        ConvertM(inGCT=inGCT3,refmatrix=CMatrix,outpath=outpath,overwrite=overwrite,FALSE)
      }
      k <- k+nthread
    }
  }
  stopCluster(cl)
}
