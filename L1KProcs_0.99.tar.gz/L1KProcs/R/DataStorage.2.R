##########################################################
## L1K Data name list generation
##
## The function can extract the list of all well names based on the gct filenames
##
## Paramters
## outpath: the path where to gct files.

## Output
## lstNames.rda: the list of well names
## lstPlates.rda: the list of plate names
## They are stored in the folder [outpath]/data_summary. 

DataStorage.2 <- function(outpath="l1kdata"){
  datapath <- outpath
  if(!file.exists(datapath)) stop(datapath," does not exists!")
  if(!file.exists(file.path(datapath,"data_summary"))){
    dir.create(file.path(datapath,"data_summary"))
  }
  outpath <- file.path(datapath,"data_summary")


  lstAllFilePaths <- list.files(path=datapath,pattern="_[A-P][0-2][0-9].gct",recursive=FALSE)
  lstAllFileNames <- unlist(strsplit(lstAllFilePaths,split="/"))
  lstDataNames <- lstAllFileNames[grep(pattern="*.gct",lstAllFileNames)]
  lstNames <- sub(".gct","",lstDataNames)
  save(lstNames,file = paste(outpath,"/lstNames.rda",sep=""))
  lstPlates <- unique(unlist(lapply(lstNames,function(x){
    tmp <- unlist(strsplit(x,"_"))
    return(paste(tmp[1:(length(tmp)-1)],collapse="_"))
  })))
  save(lstPlates,file = paste(outpath,"/lstPlates.rda",sep=""))
  return(c(length(lstPlates),length(lstNames)))
}
