########################################
##              Class                 ##
########################################

## Author: Chenglin Liu
## Date: July 2013
## License: GPL-2

######################
## Class PlateInfo  ##
######################

PlateInfo <- setClass("PlateInfo", 
                      representation = representation(
                        name = "character",
                        storepath = "character",
                        target = "character",
                        wellNaNo = "numeric",
                        controlWells = "character",
                        majorcontrol= "character", 
                        covcontrol = "matrix",
                        duplicates = "character",
                        ifquality = "logical",
                        covwells = "data.frame",
                        goodwells = "character",
                        platethresh = "numeric",
                        wellthresh ="numeric"),
                      prototype = prototype(
                        target = "default",
                        platethresh = 0.5,
                        wellthresh = 0.6))
                      

                      
setMethod("show", 
          signature(object="PlateInfo"),
          function(object) {
            expr1 <- ifelse(length(object@name) > 0,
                            object@name,"None")
            expr2 <- ifelse(length(object@storepath)>0,
                            object@storepath,
                            "None")
            expr3 <- ifelse(length(object@wellNaNo) > 0, 
                            paste(selectSub(object@wellNaNo, maxNo=4), collapse=", "),
                            "not computed")
            expr4 <- ifelse(length(object@ifquality)>0,ifelse(object@ifquality, "Yes", "No"),"not computed")
            expr5 <- ifelse(length(object@controlWells) > 0, 
                            paste(selectSub(object@controlWells, maxNo=4), collapse=", "), 
                            "None")
            expr6 <- ifelse(length(object@majorcontrol) > 0, 
                            object@majorcontrol, 
                            "None")
            expr7 <- ifelse(ncol(object@covcontrol)>0,
                            paste(selectSub(object@covcontrol, maxNo=4), collapse=", "),
                            "not computed")
            expr8 <- ifelse(length(object@duplicates)>0,
                            paste(selectSub(object@duplicates, maxNo=4), collapse=", "),
                            "not computed")
            expr9 <- ifelse(ncol(object@covwells)> 0,
                            paste(selectSub(object@covwells[,"ifwq"], maxNo=4), collapse=", "),
                            "not computed")
            expr10 <- ifelse(length(object@goodwells) > 0,
                             paste(selectSub(object@goodwells, maxNo=4), collapse=", "),
                             "None")
            expr11 <- paste("Plate:", object@platethresh,"Well:",object@wellthresh)
            cat("PlateName: ", expr1, "\n",
                "Location of expression files: ", expr2,"\n",
                "Control Wells: ", expr5,"\n",
                "Major control: ", expr6,"\n",
                "Duplicates: ", expr8,"\n",
                "Threshold: ", expr11,"\n",
                "Source of target for normalization: ",object@target,"\n",
                "Number of bad analytes: ",expr3, "\n",
                "Correlation between controls: ", expr7,"\n",
                "Correlation between wells with its duplicate: ", expr9,"\n",
                "If pass quality control: ",expr4,"\n",
                "Good wells: ", expr10,"\n",
                sep="")
          })

selectSub <- function(vec,maxNo=4){
  if(is.numeric(vec)) as.numeric(format(vec,digits=2))
  if(length(vec)>maxNo){
    return(c(vec[1:maxNo],"..."))
  }else{
    return(vec)
  }
}



